<?php
    /**
     * Plugin Name: GameFreaks - rental, membership and game coins
     * Plugin URI: http://gamefreaks.com/
     * Description: This plugin enable the option to create membership
     * accounts with the options to buy or rent products from woo commerce
     * and also the system awards you with game coins that you can use to
     * make payments on the site.
     * Version: 1.0
     * Author: Manuel Salazar and your name
     * Author URI: http://www.developerwebsite.com
     */

    require_once plugin_dir_path(__FILE__) . 'includes/functions.php';
