<?php
    //edit number of freakie
    if(isset($_POST['freakie_value'])) {
        $freakie_value = $_POST['freakie_value'];
        $wpdb->query($wpdb->prepare("UPDATE wpky_freakie_value SET freakie_value = $freakie_value WHERE id=%d", 1));
        
        header ('Location: /wp-admin/admin.php?page=freakies_value');
    }
    
    //edit number of referral_freakie_value
    if(isset($_POST['referral_freakie_value'])) {
        $referral_freakie_value = $_POST['referral_freakie_value'];
        $wpdb->query($wpdb->prepare("UPDATE wpky_referal_plan SET freakie_value = $referral_freakie_value WHERE id=%d", 1));
        
        header ('Location: /wp-admin/admin.php?page=id_referal_plan');
    }
    
    function freakies_value() {
        global $wpdb;
        $sql            = "SELECT * FROM wpky_freakie_value";
        $results        = $wpdb->get_results($sql);
        $freakie_number = $results[0]->freakie_value;
        
        $sql            = "SELECT * FROM wpky_referal_plan";
        $results        = $wpdb->get_results($sql);
        $referal_freakie_number = $results[0]->freakie_value;
        ?>
        
        <div class="w3-bar w3-black">
            <button class="w3-bar-item w3-button" onclick="openCity('id_membership_type')">Valor de Freakies</button>
            <button class="w3-bar-item w3-button" onclick="openCity('id_referal_plan')">Plan de referidos</button>
        </div>
        <?php
            if(isset($_GET['tab']) && $_GET['tab']=="id_membership_type") {
        ?>
        <div id="id_membership_type" class="w3-container city">
        <?php
            } else if(!isset($_GET['tab'])) {
        ?>
        <div id="id_membership_type" class="w3-container city">
        <?php
            } else {
        ?>
        <div id="id_membership_type" class="w3-container city" style="display:none">
        <?php
            }
        ?>  
            <h1>Valor de Freakies</h1>
            <div>
                <h1>1 peso = <?php echo $freakie_number; ?> Freakies</h1>
                <a href="/wp-admin/admin.php?page=freakies_value_edits">Editar</a>
            </div>
        </div>  
        
        <?php
            if(isset($_GET['tab']) && $_GET['tab']=="id_referal_plan") {
        ?>
        <div id="id_referal_plan" class="w3-container city">
        <?php
            } else {
        ?>
        <div id="id_referal_plan" class="w3-container city" style="display:none">
        <?php
            }
        ?>   
            <h1>Plan de referidos</h1>
            <div>
                <h1>1 referido le da al usuario: <?php echo $referal_freakie_number; ?> Freakies</h1>
                <a href="/wp-admin/admin.php?page=referal_plan_edits">Editar</a>
            </div>
        </div> 
        <?php
    }
    
    function freakies_value_edits() {
        global $wpdb;
        $sql            = "SELECT * FROM wpky_freakie_value";
        $results        = $wpdb->get_results($sql);
        $freakie_number = $results[0]->freakie_value;
        ?>
            <div class="w3-bar w3-black">
                <button class="w3-bar-item w3-button"><a href="/wp-admin/admin.php?page=freakies_value&tab=id_membership_type">Valor de Freakies</a></button>
                <button class="w3-bar-item w3-button"><a href="/wp-admin/admin.php?page=freakies_value&tab=id_referal_plan">Plan de referidos</a></button>
            </div>
            <h1>Editar valor de Freakies</h1>
            <div>
                <form action="" method="POST" style="width: 500px; margin: auto;">
                    <h1>1 peso = <span><input type="number" step="0.1" name="freakie_value" style="width: 150px; height: 40px;" value="<?php echo $freakie_number; ?>"></span> Freakies</h1>
                    <button type="submit" style="background-color: blue; border: none; color: white; float: right; padding: 15px 30px; border-radius: 10px;">Editar</a>
                </form>
            </div>
        <?php
    }
    
    function referal_plan_edits() {
        global $wpdb;
        $sql            = "SELECT * FROM wpky_referal_plan";
        $results        = $wpdb->get_results($sql);
        $referal_freakie_number = $results[0]->freakie_value;
        ?>
            <div class="w3-bar w3-black">
                <button class="w3-bar-item w3-button"><a href="/wp-admin/admin.php?page=freakies_value&tab=id_membership_type">Valor de Freakies</a></button>
                <button class="w3-bar-item w3-button"><a href="/wp-admin/admin.php?page=freakies_value&tab=id_referal_plan">Plan de referidos</a></button>
            </div>
            <h1>Editar plan de referidos</h1>
            <div>
                <form action="" method="POST" style="width: 500px; margin: auto;">
                    <h1>1 peso = <span><input type="number" name="referral_freakie_value" style="width: 150px; height: 40px;" value="<?php echo $referal_freakie_number; ?>"></span> Freakies</h1>
                    <button type="submit" style="background-color: blue; border: none; color: white; float: right; padding: 15px 30px; border-radius: 10px;">Editar</a>
                </form>
            </div>
        <?php
    }