<?php

    function freakies_packs() {
        ?>
            <h1>Paquetes de Freakies</h1>
        <?php
    }