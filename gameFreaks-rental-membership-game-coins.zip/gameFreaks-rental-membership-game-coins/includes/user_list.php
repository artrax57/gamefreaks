<?php
    function user_list() {
        global $wpdb;
        $prefix         = $wpdb->prefix;
        $paged          = isset($_GET['paged']) ? $_GET['paged'] : 1;
        $sort['name']   = isset($_GET['sort']) ? $_GET['sort'] : 'ID';
        $sort['order']  = isset($_GET['order']) ? $_GET['order'] : 'DESC';
        $sort_by        = ' ORDER BY ' . $sort['name'] . ' '. $sort['order'];
        $link           = 'admin.php?page=user_list';
        ?>
            <h1>Lista de usuarios</h1>
            <form action="<?php echo $link; ?>" method="get" style="display: none;">
                <input type="hidden" name="page" value="user_list">
                <input type="hidden" name="sort" value="<?php echo $sort['name']; ?>">
                <input type="hidden" name="order" value="<?php echo $sort['order']; ?>">
                <input type="hidden" name="paged" value="<?php echo $paged; ?>">
                <input type="submit" value="Send">
            </form>
        <?php
        
        //get all users from user table
        $sql    = "SELECT ".$prefix."users.* FROM ".$prefix."users ".$sort_by;
        $rows   = $wpdb->get_results($sql);
        
        $rows_per_page = 50;
 
        // add pagination arguments from WordPress
        $pagination_args = array(
            'base' => add_query_arg('paged','%#%'),
            'format' => '',
            'total' => ceil(sizeof($rows)/$rows_per_page),
            'current' => $paged,
            'show_all' => false,
            'type' => 'plain',
        );
 
        $start          = ($paged - 1) * $rows_per_page;
        $end_initial    = $start + $rows_per_page;
        $end            = (sizeof($rows) < $end_initial) ? sizeof($rows) : $end_initial;
        
        if (count($rows) > 0) {
            // prepare link for pagination
            $link .= '&paged=' . $paged;
            $order = $sort['order'] == "ASC" ? "DESC" : "ASC";
        ?>
            <table id="user-sent-mail" class="wp-list-table widefat fixed users">
                <thead>
                    <tr class="manage-column">
                        <th class="col-from">
                            <a href="<?php echo $link.'&sort=&order='.$order; ?>">
                                Nombre
                            </a>
                        </th>
                        <th class="col-subject">
                            <a href="<?php echo $link.'&sort=&order='.$order; ?>">
                                Correo
                            </a>
                        </th>
                        <th class="col-body">
                            <a href="<?php echo $link.'&sort=&order='.$order; ?>">
                                Cantidad de rentas
                            </a>
                        </th>
                        <th class="col-created">
                            <a href="<?php echo $link.'&sort=&order='.$order; ?>">
                                Plan de renta actual
                            </a>
                        </th>
                        <th class="col-created">
                            <a href="<?php echo $link.'&sort=&order='.$order; ?>">
                                Títulos en renta
                            </a>
                        </th>
                        <th class="col-created">
                            <a href="<?php echo $link.'&sort=&order='.$order; ?>">
                                Status
                            </a>
                        </th>
                    </tr>
                </thead>
                <tbody>
        <?php
            for ($index = $start; $index < $end;  ++$index) {
                $row = $rows[$index];
                $class_row = ($index % 2 == 1 ) ? ' class="alternate"' : '';
                
                //get membership status for each user from user_membership table
                $sql    = "SELECT ".$prefix."user_membership.id, ".$prefix."user_membership.status AS STATUS 
                            FROM ".$prefix."user_membership 
                            WHERE is_paid=1 AND ".$prefix."user_membership.user_id=".$row->ID." 
                            ORDER BY ".$prefix."user_membership.id DESC LIMIT 1";
                $result = $wpdb->get_results($sql);
                $status = 0;
                if(count($result)>0) {
                    $status = $result[0]->STATUS;
                }
                $user_id    = $row->ID;
                $fullName   = get_user_meta( $user_id, 'first_name', true )." ".get_user_meta( $user_id, 'last_name', true );
                $user       = get_user_by( 'ID', $user_id );

                //get all game that are rented and not returend from wishlist for each user
                $sql        = "SELECT * 
                                FROM ".$prefix."wishlist 
                                WHERE user_id=".$user_id." AND confirmed_delivery=1 AND expired_date IS NULL";
                $titles     = $wpdb->get_results($sql);

                //get membership name that is active now for each user
                $sql = "SELECT ".$prefix."membership_types.membership_name AS MEMEBERSHIP_NAME
                        FROM ".$prefix."users LEFT JOIN ".$prefix."user_membership ON ".$prefix."users.ID=".$prefix."user_membership.user_id 
                                        LEFT JOIN ".$prefix."membership_recurring_payments ON ".$prefix."membership_recurring_payments.id=".$prefix."user_membership.membership_option_id
                                        LEFT JOIN ".$prefix."membership_types ON ".$prefix."membership_types.id=".$prefix."membership_recurring_payments.membership_id
                        WHERE is_paid=1 AND ".$prefix."user_membership.user_id=".$user_id." ORDER BY ".$prefix."user_membership.id DESC LIMIT 1";
                $membership_name = $wpdb->get_results($sql);

                //get all rented games that are in progress now for each user
                $sql            = "SELECT ".$prefix."wishlist.*, ".$prefix."posts.post_title as Game_Name 
                                    FROM ".$prefix."wishlist INNER JOIN ".$prefix."posts ON ".$prefix."wishlist.product_id=".$prefix."posts.ID AND ".$prefix."wishlist.confirmed_delivery=1 
                                    WHERE ".$prefix."wishlist.is_returned=0 AND user_id=".$user_id." ".$sort_by;
                $rentedGames    = $wpdb->get_results($sql);
            ?>
                <tr <?php echo $class_row; ?>>
                    <td> <a href="/wp-admin/admin.php?page=user_detail&id=<?php echo $row->ID; ?>"><?php echo $fullName; ?></a></td>
                    <td> <a href="/wp-admin/admin.php?page=user_detail&id=<?php echo $row->ID; ?>"><?php echo $user->user_email; ?></a></td>
                    <td> <a href="/wp-admin/admin.php?page=user_detail&id=<?php echo $row->ID; ?>"><?php echo count($titles); ?></a></td>
                    <td> 
                        <a href="/wp-admin/admin.php?page=user_detail&id=<?php echo $row->ID; ?>">
                            <?php if(count($membership_name)>0) {
                                echo $membership_name[0]->MEMEBERSHIP_NAME;
                            } ?>
                        </a>
                    </td>
                    <td> 
                        <?php 
                            if(count($rentedGames)>0) { 
                                foreach($rentedGames as $key =>$game) {
                                    echo "<p>".$game->Game_Name."</p>";
                                } 
                            }
                        ?>
                    </td>
                    <td>
                        <?php 
                            if($status==-1) {
                                echo "<a href='/wp-admin/admin.php?page=user_detail&id=".$row->ID."'>Suspended</a>";
                            } else if($status == 1) {
                                echo "<a href='/wp-admin/admin.php?page=user_detail&id=".$row->ID."'>Active</a>";
                            } else {
                                echo "<a href='/wp-admin/admin.php?page=user_detail&id=".$row->ID."'></a>";
                            } 
                        ?>
                    </td>
                </tr>
            <?php
                }
            ?>
            </tbody>
        </table>
        <?php
            // add pagination links from WordPress
            echo paginate_links($pagination_args);
        
        } else {
            ?>
            <p>No records found, try again please</p>
        <?php
        } // endif count($rows)
    }