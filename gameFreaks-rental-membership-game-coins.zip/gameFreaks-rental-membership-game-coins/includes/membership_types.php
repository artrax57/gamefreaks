<?php
    global $wpdb;
    
    //add new membership
    if(isset($_POST['edit_membership_id'])) {
        $id                         = $_POST['edit_membership_id'];
        $membership_title           = $_POST['membership_title'];
        $title_number               = $_POST['title_number'];
        $membership_price           = $_POST['membership_price'];
        $accept_freakies            = $_POST['accept_freakies'];
        $accept_product_freakies    = $_POST['accept_product_freakies'];
        $membership_status          = $_POST['membership_status'];
        $wpdb->query($wpdb->prepare("UPDATE wpky_membership_types SET membership_name = '$membership_title', titles_number = $title_number, membership_price = $membership_price, accept_freakies = $accept_freakies, accept_physical_product = $accept_product_freakies, membership_status=$membership_status WHERE id=%d", $id));
        
        header ('Location: /wp-admin/admin.php?page=membership_types&tab=id_membership_type');
    }
    
    //else new membership
    else if(isset($_POST['membership_title'])) {
        $membership_title           = $_POST['membership_title'];
        $title_number               = $_POST['title_number'];
        $membership_price           = $_POST['membership_price'];
        $accept_freakies            = $_POST['accept_freakies'];
        $accept_product_freakies    = $_POST['accept_product_freakies'];
        $membership_status          = $_POST['membership_status'];
        $wpdb->insert('wpky_membership_types', array('membership_name' => $membership_title, 'titles_number' => $title_number, 'membership_price' => $membership_price, 'accept_freakies' => $accept_freakies, 'accept_physical_product' => $accept_product_freakies, 'membership_status' => $membership_status));
    
        header ('Location: /wp-admin/admin.php?page=membership_types&tab=id_membership_type');
    }
    
    //add new membership
    if(isset($_POST['edit_recurring_payment_id'])) {
        $id                         = $_POST['edit_recurring_payment_id'];
        $membership_id              = $_POST['recurring_membership_name'];
        $monthly_frequency          = $_POST['monthly_frequency'];
        $recurring_price            = $_POST['recurring_price'];
        $status                     = $_POST['status'];
        $paypal_code                = addslashes($_POST['paypal_code']);

        if(empty($_POST['edit_recurring_payment_id'])) {
            $wpdb->insert('wpky_membership_recurring_payments', array('paypal_code' => $paypal_code, 'membership_id' => $membership_id, 'price' => $recurring_price, 'monthly_frequency' => $monthly_frequency, 'status' => $status));
        } else {
            $wpdb->query($wpdb->prepare("UPDATE wpky_membership_recurring_payments SET paypal_code = '$paypal_code', membership_id = '$membership_id', price = $recurring_price, monthly_frequency = $monthly_frequency, status = $status WHERE id=%d", $id));
        }

        header ('Location: /wp-admin/admin.php?page=membership_types&tab=id_recurring_payments');
    }
    
    //add new recurring payment
    else if(isset($_POST['recurring_membership_name'])) {
        $membership_id              = $_POST['recurring_membership_name'];
        $monthly_frequency          = $_POST['monthly_frequency'];
        $recurring_price            = $_POST['recurring_price'];
        $status                     = $_POST['status'];
        $paypal_code                = addslashes($_POST['paypal_code']);
        $wpdb->insert('wpky_membership_recurring_payments', array('paypal_code' => $paypal_code, 'membership_id' => $membership_id, 'price' => $recurring_price, 'monthly_frequency' => $monthly_frequency, 'status' => $status));
        
        header ('Location: /wp-admin/admin.php?page=membership_types&tab=id_recurring_payments');
    }
    
    function membership_types() {
        global $wpdb;
        ?>
            <h1>Tipos de membresía</h1>
            <div class="w3-bar w3-black">
              <button class="w3-bar-item w3-button" onclick="openCity('id_membership_type')">Tipos de membresía</button>
              <button class="w3-bar-item w3-button" onclick="openCity('id_add_membership')">Agregar membresía</button>
              <button class="w3-bar-item w3-button" onclick="openCity('id_recurring_payments')">Pagos recurrentes</button>
              <button class="w3-bar-item w3-button" onclick="openCity('id_add_recurring_payment')">Agregar Pago recurrente</button>
            </div>
            
            <?php
                if(isset($_GET['tab']) && $_GET['tab']=="id_membership_type") {
            ?>
            <div id="id_membership_type" class="w3-container city">
            <?php
                } else if(!isset($_GET['tab'])) {
            ?>
            <div id="id_membership_type" class="w3-container city">
            <?php
                } else {
            ?>
            <div id="id_membership_type" class="w3-container city" style="display:none">
            <?php
                }
            ?>
                <h2>Tipos de membresía</h2>
                <table class="border-tbl">
                    <tr>
                        <th>Nombre de la cuenta</th>
                        <th>Cantidad de títulos</th>
                        <th>Status</th>
                        <th>Costo de inscripcion</th>
                        <th>Acepta freakies</th>
                        <th>Acepta prodcto físico</th>
                        <th></th> 
                    </tr>
                    <?php
                        $sql         = "SELECT * FROM wpky_membership_types;";
                        $memberships = $wpdb->get_results($sql);
                        for($i=0; $i<count($memberships); $i++) {
                            $membership=json_decode(json_encode($memberships[$i]), true);
                    ?>
                    
                    <tr>
                        <td><?php echo $membership['membership_name']?></td>
                        <td><?php echo $membership['titles_number']?></td>
                        <td>
                            <?php 
                            if($membership['membership_status']==1)
                                echo "Activo";
                            else
                                echo "Desactivo";
                            ?>
                        </td>
                        <td>$<?php echo $membership['membership_price']?></td>
                        <td>
                            <?php 
                            if($membership['accept_freakies']==1)
                                echo "Si";
                            else
                                echo "No";
                            ?>
                        </td>
                        <td>
                            <?php 
                            if($membership['accept_physical_product']==1)
                                echo "Si";
                            else
                                echo "No";
                            ?>
                        </td>
                        <td><a href="/wp-admin/admin.php?page=edit_membership&id=<?php echo $membership['id']?>">editar</a></td>
                    </tr>
                    <?php
                        }
                    ?>
                </table>
            </div>
            
            <?php
                if(isset($_GET['tab']) && $_GET['tab']=="id_add_membership") {
            ?>
            <div id="id_add_membership" class="w3-container city">
            <?php
                } else {
            ?>
            <div id="id_add_membership" class="w3-container city" style="display: none;">
            <?php
                }
            ?>
                <h2>Agregar membresía</h2>
                <form action="" method="POST">
                    <table class="add-membership-tbl">
                        <tr>
                            <td style="text-align: right;"><b>Títuto de membresía:</b></td>
                            <td><input type="text" name="membership_title"></td>
                        </tr>
                        <tr>
                            <td style="text-align: right;"><b>Cantidad de titulos:</b></td>
                            <td>
                                <select name="title_number">
                                    <option value="1">1</option>
                                    <option value="2">2</option>
                                    <option value="3">3</option>
                                    <option value="4">4</option>
                                    <option value="5">5</option>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <td style="text-align: right;"><b>Costo de inscripcíon:</b></td>
                            <td><input type="number" name="membership_price"></td>
                        </tr>
                        <tr>
                            <td style="text-align: right;"><b>Acepta Freakies:</b></td>
                            <td>
                                <input type="radio" id="accept_freakies_yes" name="accept_freakies" value="1">
                                <label for="accept_freakies_yes">Si</label>
                                <input type="radio" id="accept_freakies_no" name="accept_freakies" value="0">
                                <label for="accept_freakies_no">No</label>
                            </td>
                        </tr>
                        <tr>
                            <td style="text-align: right;"><b>Acepta producto físico:</b></td>
                            <td>
                                <input type="radio" id="accept_product_freakies_yes" name="accept_product_freakies" value="1">
                                <label for="accept_product_freakies_yes">Si</label>
                                <input type="radio" id="accept_product_freakies_no" name="accept_product_freakies" value="0">
                                <label for="accept_product_freakies_no">No</label>
                            </td>
                        </tr>
                        <tr>
                            <td style="text-align: right;"><b>Status:</b></td>
                            <td>
                                <select name="membership_status">
                                    <option value="1">Activo</option>
                                    <option value="0">Desactivado</option>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" style="text-align: center;">
                                <button type="submit" class="button" style="background-color: #008CBA;">Agregar</button>
                            </td>
                        </tr>
                    </table>
                </form>
            </div>
            <?php
                if(isset($_GET['tab']) && $_GET['tab']=="id_recurring_payments") {
            ?>
            <div id="id_recurring_payments" class="w3-container city">
            <?php
                } else {
            ?>
            <div id="id_recurring_payments" class="w3-container city" style="display:none">
            <?php
                }
            ?>
            
                <h2>Pagos recurrentes</h2>
                <div style="width: 100%; text-align: right;">
                    <a href="/wp-admin/admin.php?page=recurring_payments_edits">Create a new Membership</a>
                </div>
                <table class="border-tbl">
                    <tr>
                        <th>Membresia</th>
                        <th>Frecuencia mensual</th>
                        <th>Costo</th>
                        <th>Status</th>
                        <th></th> 
                    </tr>
                    <?php
                        $sql ="SELECT wpky_membership_types.membership_name, wpky_membership_recurring_payments.* FROM wpky_membership_types RIGHT JOIN wpky_membership_recurring_payments ON wpky_membership_recurring_payments.membership_id=wpky_membership_types.id";
                        $results = $wpdb->get_results($sql);
                        for($i=0; $i<count($results); $i++) {
                            $item=json_decode(json_encode($results[$i]), true);
                    ?>
                    <tr>
                        <td><?php echo $item['membership_name']?></td>
                        <td><?php echo $item['monthly_frequency']?></td>
                        <td>$<?php echo $item['price']?></td>
                        <td>
                            <?php 
                            if($item['status']==1)
                                echo "Activo";
                            else
                                echo "Desactivo";
                            ?>
                        </td>
                        <td><a href="/wp-admin/admin.php?page=recurring_payments_edits&id=<?php echo $item['id']?>">editar</a></td>
                    </tr>
                    <?php
                        }
                    ?>
                </table>
            </div>
            <?php
                if(isset($_GET['tab']) && $_GET['tab']=="id_add_recurring_payment") {
            ?>
            <div id="id_add_recurring_payment" class="w3-container city">
            <?php
                } else {
            ?>
            <div id="id_add_recurring_payment" class="w3-container city" style="display:none">
            <?php
                }
            ?>
            
                <h2>Agregar Pago recurrente</h2>
                <form action="" method="POST" id="id_edit_recurring_payment_form">
                    <table class="add-membership-tbl">
                        <tr>
                            <td style="text-align: right;"><b>Nombre de la membresía:</b></td>
                            <td>
                                <select name="recurring_membership_name">
                                    <?php
                                        for($i=0; $i<count($memberships); $i++) {
                                            $membership=json_decode(json_encode($memberships[$i]), true);
                                    ?>
                                    <option value="<?php echo $membership['id']?>"><?php echo $membership['membership_name']?></option>
                                    <?php
                                        }
                                    ?>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <td style="text-align: right;"><b>Frecuencia mensual:</b></td>
                            <td>
                                <select name="monthly_frequency">
                                    <option value="1">1</option>
                                    <option value="2">2</option>
                                    <option value="3">3</option>
                                    <option value="4">4</option>
                                    <option value="5">5</option>
                                    <option value="6">6</option>
                                    <option value="7">7</option>
                                    <option value="8">8</option>
                                    <option value="9">9</option>
                                    <option value="10">10</option>
                                    <option value="11">11</option>
                                    <option value="12">12</option>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <td style="text-align: right;"><b>Costo:</b></td>
                            <td><input type="number" name="recurring_price"></td>
                        </tr>
                        <tr>
                            <td style="text-align: right;"><b>Status:</b></td>
                            <td>
                                <select name="status">
                                    <option value="1">Activo</option>
                                    <option value="0">Desactivado</option>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <td style="text-align: right;"><b>Codigo Paypal:</b></td>
                            <td>
                                <textarea name="paypal_code" id="paypal_code" cols="30" rows="10"><?php if(isset($item)) echo $item['paypal_code'];?></textarea>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" style="text-align: center;">
                                <button type="button" class="button" style="background-color: #008CBA;" onclick="editMembership()">Agregar</button>
                            </td>
                        </tr>
                    </table>
                </form>
            </div>
        <?php
    }
    
    function edit_membership() {
        global $wpdb;
        $sql         = "SELECT * FROM wpky_membership_types WHERE id=".$_GET['id'];
        $memberships = $wpdb->get_results($sql);
        $membership =json_decode(json_encode($memberships[0]), true);
        ?>
            <div class="w3-bar w3-black">
              <button class="w3-bar-item w3-button"><a href="/wp-admin/admin.php?page=membership_types&tab=id_membership_type">Tipos de membresía</a></button>
              <button class="w3-bar-item w3-button"><a href="/wp-admin/admin.php?page=membership_types&tab=id_add_membership">Agregar membresía</a></button>
              <button class="w3-bar-item w3-button"><a href="/wp-admin/admin.php?page=membership_types&tab=id_recurring_payments">Pagos recurrentes</a></button>
              <button class="w3-bar-item w3-button"><a href="/wp-admin/admin.php?page=membership_types&tab=id_add_recurring_payment">Agregar Pago recurrente</a></button>
            </div>
            <div id="id_add_membership" class="w3-container city">
                <h2>Editar membresía</h2>
                <form action="" method="POST">
                    <input type="hidden" name="edit_membership_id" value="<?php echo $membership['id']?>">
                    <table class="add-membership-tbl">
                        <tr>
                            <td style="text-align: right;"><b>Títuto de membresía:</b></td>
                            <td><input type="text" name="membership_title" value="<?php echo $membership['membership_name']?>"></td>
                        </tr>
                        <tr>
                            <td style="text-align: right;"><b>Cantidad de titulos:</b></td>
                            <td>
                                <select name="title_number">
                                    <option value="1" <?=$membership['titles_number'] == 1 ? ' selected="selected"' : '';?>>1</option>
                                    <option value="2" <?=$membership['titles_number'] == 2 ? ' selected="selected"' : '';?>>2</option>
                                    <option value="3" <?=$membership['titles_number'] == 3 ? ' selected="selected"' : '';?>>3</option>
                                    <option value="4" <?=$membership['titles_number'] == 4 ? ' selected="selected"' : '';?>>4</option>
                                    <option value="5" <?=$membership['titles_number'] == 5 ? ' selected="selected"' : '';?>>5</option>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <td style="text-align: right;"><b>Costo de inscripcíon:</b></td>
                            <td><input type="number" name="membership_price" value="<?php echo $membership['membership_price']?>"></td>
                        </tr>
                        <tr>
                            <td style="text-align: right;"><b>Acepta Freakies:</b></td>
                            <td>
                                <input type="radio" id="accept_freakies_yes" name="accept_freakies" value="1" <?=$membership['accept_freakies'] == 1 ? ' checked="checked"' : '';?>>
                                <label for="accept_freakies_yes">Si</label>
                                <input type="radio" id="accept_freakies_no" name="accept_freakies" value="0" <?=$membership['accept_freakies'] == 0 ? ' checked="checked"' : '';?>>
                                <label for="accept_freakies_no">No</label>
                            </td>
                        </tr>
                        <tr>
                            <td style="text-align: right;"><b>Acepta producto físico:</b></td>
                            <td>
                                <input type="radio" id="accept_product_freakies_yes" name="accept_product_freakies" value="1" <?=$membership['accept_physical_product'] == 1 ? ' checked="checked"' : '';?>>
                                <label for="accept_product_freakies_yes">Si</label>
                                <input type="radio" id="accept_product_freakies_no" name="accept_product_freakies" value="0" <?=$membership['accept_physical_product'] == 0 ? ' checked="checked"' : '';?>>
                                <label for="accept_product_freakies_no">No</label>
                            </td>
                        </tr>
                        <tr>
                            <td style="text-align: right;"><b>Status:</b></td>
                            <td>
                                <select name="membership_status">
                                    <option value="1" <?=$membership['membership_status'] == 1 ? ' selected="selected"' : '';?>>Activo</option>
                                    <option value="0" <?=$membership['membership_status'] == 0 ? ' selected="selected"' : '';?>>Desactivado</option>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" style="text-align: center;">
                                <button type="submit" class="button" style="background-color: #008CBA;">Editar</button>
                            </td>
                        </tr>
                    </table>
                </form>
            </div>
        <?php
    }
    
    function recurring_payments_edits() {
        global $wpdb;
        if(isset($_GET['id'])) {
            $sql         = "SELECT * FROM wpky_membership_recurring_payments WHERE id=".$_GET['id'];
            $results     = $wpdb->get_results($sql);
            $item        = json_decode(json_encode($results[0]), true);
        }
        $sql         = "SELECT * FROM wpky_membership_types;";
        $memberships = $wpdb->get_results($sql);
        ?>
            <div class="w3-bar w3-black">
              <button class="w3-bar-item w3-button"><a href="/wp-admin/admin.php?page=membership_types&tab=id_membership_type">Tipos de membresía</a></button>
              <button class="w3-bar-item w3-button"><a href="/wp-admin/admin.php?page=membership_types&tab=id_add_membership">Agregar membresía</a></button>
              <button class="w3-bar-item w3-button"><a href="/wp-admin/admin.php?page=membership_types&tab=id_recurring_payments">Pagos recurrentes</a></button>
              <button class="w3-bar-item w3-button"><a href="/wp-admin/admin.php?page=membership_types&tab=id_add_recurring_payment">Agregar Pago recurrente</a></button>
            </div>
            <div id="id_add_membership" class="w3-container city">
                <h2>Editar membresía</h2>
                <form action="" method="POST" id="id_edit_recurring_payment_form">
                    <input type="hidden" name="edit_recurring_payment_id" value="<?php if(isset($item)) echo $item['id']?>">
                    <table class="add-membership-tbl">
                        <tr>
                            <td style="text-align: right;"><b>Nombre de la membresía:</b></td>
                            <td>
                                <select name="recurring_membership_name">
                                    <?php
                                        for($i=0; $i<count($memberships); $i++) {
                                            $membership=json_decode(json_encode($memberships[$i]), true);
                                    ?>
                                    <option value="<?php echo $membership['id']?>" <?php if(isset($item) && $item['membership_id'] == $membership['id']) echo "selected"; ?>><?php echo $membership['membership_name']?></option>
                                    <?php
                                        }
                                    ?>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <td style="text-align: right;"><b>Frecuencia mensual:</b></td>
                            <td>
                                <select name="monthly_frequency">
                                    <option value="1" <?php if(isset($item) && $item['monthly_frequency'] == 1) echo "selected"; ?>>1</option>
                                    <option value="2" <?php if(isset($item) && $item['monthly_frequency'] == 2) echo "selected"; ?>>2</option>
                                    <option value="3" <?php if(isset($item) && $item['monthly_frequency'] == 3) echo "selected"; ?>>3</option>
                                    <option value="4" <?php if(isset($item) && $item['monthly_frequency'] == 4) echo "selected"; ?>>4</option>
                                    <option value="5" <?php if(isset($item) && $item['monthly_frequency'] == 5) echo "selected"; ?>>5</option>
                                    <option value="6" <?php if(isset($item) && $item['monthly_frequency'] == 6) echo "selected"; ?>>6</option>
                                    <option value="7" <?php if(isset($item) && $item['monthly_frequency'] == 7) echo "selected"; ?>>7</option>
                                    <option value="8" <?php if(isset($item) && $item['monthly_frequency'] == 8) echo "selected"; ?>>8</option>
                                    <option value="9" <?php if(isset($item) && $item['monthly_frequency'] == 9) echo "selected"; ?>>9</option>
                                    <option value="10" <?php if(isset($item) && $item['monthly_frequency'] == 10) echo "selected"; ?>>10</option>
                                    <option value="11" <?php if(isset($item) && $item['monthly_frequency'] == 11) echo "selected"; ?>>11</option>
                                    <option value="12" <?php if(isset($item) && $item['monthly_frequency'] == 12) echo "selected"; ?>>12</option>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <td style="text-align: right;"><b>Costo:</b></td>
                            <td><input type="number" name="recurring_price" value="<?php if(isset($item)) echo $item['price']?>"></td>
                        </tr>
                        <tr>
                            <td style="text-align: right;"><b>Status:</b></td>
                            <td>
                                <select name="status">
                                    <option value="1" <?php if(isset($item) && $item['status'] == 1) echo "selected"; ?> >Activo</option>
                                    <option value="0" <?php if(isset($item) && $item['status'] == 0) echo "selected"; ?> >Desactivado</option>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <td style="text-align: right;"><b>Codigo Paypal:</b></td>
                            <td>
                                <textarea name="paypal_code" id="paypal_code" cols="30" rows="10"><?php if(isset($item)) echo $item['paypal_code'];?></textarea>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" style="text-align: center;">
                                <button type="button" class="button" style="background-color: #008CBA;" onclick="editMembership()">Editar</button>
                            </td>
                        </tr>
                    </table>
                </form>
            </div>
        <?php
    }