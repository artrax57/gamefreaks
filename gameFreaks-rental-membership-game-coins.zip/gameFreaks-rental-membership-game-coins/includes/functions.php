<?php
    /*
     * Add my new menu to the Admin Control Panel
    */
    require_once plugin_dir_path(__FILE__) . 'rental_list.php'; 
    require_once plugin_dir_path(__FILE__) . 'games_in_stock.php'; 
    require_once plugin_dir_path(__FILE__) . 'user_list.php'; 
    require_once plugin_dir_path(__FILE__) . 'payment_list.php'; 
    require_once plugin_dir_path(__FILE__) . 'freakies_value.php'; 
    require_once plugin_dir_path(__FILE__) . 'freakies_packs.php'; 
    require_once plugin_dir_path(__FILE__) . 'membership_types.php'; 
    require_once plugin_dir_path(__FILE__) . 'user_detail.php';
    // Hook the 'admin_menu' action hook, run the function named 'gameFreaks_rental_membership_game_coins_Admin_Link()'
    add_action( 'admin_menu', 'gameFreaks_rental_membership_game_coins_Admin_Link' );

    // Add a new top level menu link to the ACP
    function gameFreaks_rental_membership_game_coins_Admin_Link()
    {
        $plugin_page = add_menu_page(
            'Header & Footer Scripts', // Title of the page
            'Gamefreaks', // Text to show on the menu link
            'manage_options', // Capability requirement to see the link
            'grm-admin-menu',
            'grm_page', // The 'slug' - file to display when clicking the link
            '/wp-content/uploads/2020/08/cropped-Icon-32x32.png',
            200
        );
        
        add_action( 'load-' . $plugin_page, 'add_js_script' );
        $rental_list = add_submenu_page( 'grm-admin-menu', 'Lista de rentas'        , 'Lista de rentas'         , 'manage_options', 'rental_list', 'rental_list');
        add_action( 'load-' . $rental_list, 'add_js_script' );
        $games_in_stock = add_submenu_page( 'grm-admin-menu', 'Juegos en stock'     , 'Juegos en stock'         , 'manage_options', 'games_in_stock', 'games_in_stock');
        add_action( 'load-' . $games_in_stock, 'add_js_script' );
        $user_list = add_submenu_page( 'grm-admin-menu', 'Lista de usuarios'        , 'Lista de usuarios'       , 'manage_options', 'user_list', 'user_list');
        add_action( 'load-' . $user_list, 'add_js_script' );  
        $payment_list = add_submenu_page( 'grm-admin-menu', 'Lista de pagos'        , 'Lista de pagos'          , 'manage_options', 'payment_list', 'payment_list');
        add_action( 'load-' . $payment_list, 'add_js_script' ); 
        $freakies_value = add_submenu_page( 'grm-admin-menu', 'Valor de Freakies'   , 'Valor de Freakies'       , 'manage_options', 'freakies_value', 'freakies_value');
        add_action( 'load-' . $freakies_value, 'add_js_script' );
        $freakies_packs = add_submenu_page( 'grm-admin-menu', 'Paquetes de Freakies', 'Paquetes de Freakies'   , 'manage_options', 'freakies_packs', 'freakies_packs');
        add_action( 'load-' . $freakies_packs, 'add_js_script' );
        $membership_types = add_submenu_page( 'grm-admin-menu', 'Tipos de membresía' , 'Tipos de membresía'      , 'manage_options', 'membership_types', 'membership_types');
        add_action( 'load-' . $membership_types, 'add_js_script' );
        
        $membership_edits = add_submenu_page( null, 'Editar membresía' , 'Editar membresía'      , 'manage_options', 'edit_membership', 'edit_membership');
        add_action( 'load-' . $membership_edits, 'add_js_script' );
        $recurring_payments_edits = add_submenu_page( null, 'Editar Pago recurrente' , 'Editar Pago recurrente'      , 'manage_options', 'recurring_payments_edits', 'recurring_payments_edits');
        add_action( 'load-' . $recurring_payments_edits, 'add_js_script' );
        $freakies_value_edits = add_submenu_page( null, 'Editar valorde Freakies' , 'Editar valorde Freakies'      , 'manage_options', 'freakies_value_edits', 'freakies_value_edits');
        add_action( 'load-' . $freakies_value_edits, 'add_js_script' );
        $referal_plan_edits = add_submenu_page( null, 'Editar valorde Freakies' , 'Editar valorde Freakies'      , 'manage_options', 'referal_plan_edits', 'referal_plan_edits');
        add_action( 'load-' . $referal_plan_edits, 'add_js_script' );
        $user_detail = add_submenu_page( null, 'Detalle de usuario' , 'Detalle de usuario'      , 'manage_options', 'user_detail', 'user_detail');
        add_action( 'load-' . $user_detail, 'add_js_script' );
        $user_detail_edit = add_submenu_page( null, 'Detalle de usuario' , 'Detalle de usuario'      , 'manage_options', 'user_detail_edit', 'user_detail_edit');
        add_action( 'load-' . $user_detail_edit, 'add_js_script' );
        $admin_wishlist = add_submenu_page( null, '' , ''      , 'manage_options', 'admin_wishlist', 'admin_wishlist');
        add_action( 'load-' . $admin_wishlist, 'add_js_script' );
        
        $admin_edit_membership = add_submenu_page( null, '' , ''      , 'manage_options', 'admin_edit_membership', 'admin_edit_membership');
        add_action( 'load-' . $admin_edit_membership, 'add_js_script' );
    }

    function add_js_script() {
        $version = rand(111,9999);
        wp_enqueue_style( 'fontawesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css', array(), $version, 'all' );
        wp_enqueue_style( 'w3_css', 'https://www.w3schools.com/w3css/4/w3.css', array(), $version, 'all' );
        wp_enqueue_style( 'style', plugins_url( 'css/style.css', __FILE__ ), array(), $version, 'all' );
        //wp_enqueue_script( 'jquery_js', "https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js", array('jquery'), $version, true);
        wp_enqueue_script( 'grm_js', plugins_url( 'js/script.js', __FILE__ ), array('jquery'), $version, true);
        wp_localize_script( 'grm_js', 'grm_js_object', array( 'ajaxurl' => admin_url( 'admin-ajax.php' ), 'grm_ajax_nonce' => wp_create_nonce('grm-fro-form-ajax'), 'grm_site_url' => site_url() ) );
    }

    function grm_page() {
    
    }