<?php
    function user_detail() {
        global $wpdb;
        $prefix     = $wpdb->prefix;
        $user_id    = $_GET['id'];
        $user       = get_user_by('ID', $user_id);
        $user_meta  = get_user_meta ($user_id);
?>
        <h1 class="text-center">Detalle de usuario</h1>
        <div class="w-100 d-flex">
            <div class="tbl_user">
                <table>
                    <tr>
                        <td class="text-right">Nombre(s):</td>
                        <td class="text-left"><input type="text" value="<?php echo $user_meta['first_name'][0]; ?>" name="first_name"></td>
                    </tr>
                    <tr>
                        <td class="text-right">Apellidos:</td>
                        <td class="text-left"><input type="text" value="<?php echo $user_meta['last_name'][0]; ?>" name="last_name"></td>
                    </tr>
                    <tr>
                        <td class="text-right">Fecha de nacimiento:</td>
                        <td class="text-left"><input type="text" value="<?php if(isset($user_meta['birthday'])) echo $user_meta['birthday'][0]; ?>" name="birthday"></td>
                    </tr>
                    <tr>
                        <td class="text-right">
                            Dirección:<br>
                            Calle:
                        </td>
                        <td class="text-left"><input type="text" value="<?php if(isset($user_meta['street'])) echo $user_meta['street'][0]; ?>" name="street"></td>
                    </tr>
                    <tr>
                        <td class="text-right">Número exterior:</td>
                        <td class="text-left"><input type="text" value="<?php if(isset($user_meta['outdoor_number'])) echo $user_meta['outdoor_number'][0]; ?>" name="outdoor_number"></td>
                    </tr>
                    <tr>
                        <td class="text-right">Número interior:</td>
                        <td class="text-left"><input type="text" value="<?php if(isset($user_meta['inner_number'])) echo $user_meta['inner_number'][0]; ?>" name="inner_number"></td>
                    </tr>
                    
                    <tr>
                        <td class="text-right">Colonia:</td>
                        <td class="text-left"><input type="text" value="<?php if(isset($user_meta['cologne'])) echo $user_meta['cologne'][0]; ?>" name="cologne"></td>
                    </tr>
                    <tr>
                        <td class="text-right">Municipio:</td>
                        <td class="text-left"><input type="text" value="<?php if(isset($user_meta['municipio'])) echo $user_meta['municipio'][0]; ?>" name="municipio"></td>
                    </tr>
                    <tr>
                        <td class="text-right">Código Postal:</td>
                        <td class="text-left"><input type="text" value="<?php if(isset($user_meta['postal'])) echo $user_meta['postal'][0]; ?>" name="postal"></td>
                    </tr>
                    <tr>
                        <td class="text-right">Correo electrónico:</td>
                        <td class="text-left"><input type="text" value="<?php echo $user->user_email; ?>" name="user_email"></td>
                    </tr>
                    <tr>
                        <td class="text-right">Estado:</td>
                        <td class="text-left"><input type="text" value="<?php if(isset($user_meta['state'])) echo $user_meta['state'][0]; ?>" name="state"></td>
                    </tr>
                    <tr>
                        <td class="text-right">Teléfono:</td>
                        <td class="text-left"><input type="text" value="<?php if(isset($user_meta['phone'])) echo $user_meta['phone'][0]; ?>" name="phone"></td>
                    </tr>
                </table>
                <a href="/wp-admin/admin.php?page=user_detail_edit&id=<?php echo $user_id; ?>" class="btn-edit-profile ma-au">Editar</a>
            </div>
            <div>
                <?php
                    $sql = "SELECT * 
                            FROM ".$prefix."user_membership 
                                LEFT JOIN ".$prefix."membership_recurring_payments ON ".$prefix."user_membership.membership_option_id= ".$prefix."membership_recurring_payments.id 
                                LEFT JOIN ".$prefix."membership_types ON ".$prefix."membership_types.id=".$prefix."membership_recurring_payments.membership_id 
                            WHERE ".$prefix."user_membership.user_id=".$user_id;
                    $rows = $wpdb->get_results($sql);
                ?>
                <table class="membership-detail">
                    <tr>
                        <td>
                            <h4><b>Tipo de cuenta</b></h4>
                            <?php 
                                if(count($rows)>0){
                                    echo "<h5>".$rows[0]->membership_name."</h5>";
                                    echo "<p>";
                                    echo "  <b>Frecuencia de pago: </b>".$rows[0]->monthly_frequency." meses <br>";
                                    echo "  <b>Fecha de inicio de membresía: </b>".$rows[0]->registered_date." <br>";
                                    if($rows[0]->is_paid==1) {
                                        echo "<b>Fecha de próximo cargo: </b>".$rows[0]->expired_date." <br>";
                                    } else {
                                        echo "<b>Fecha de próximo cargo: </b>Pago pendiente <br>";
                                    }

                                    if($rows[0]->status==1) {
                                        echo "<b>Status de cuenta: </b>Activo";
                                    } else {
                                        echo "<b>Status de cuenta: </b>Deactivo";
                                    }
                                    echo "</p>";
                                }   
                            ?>
                        </td>
                        <td><a href="/wp-admin/admin.php?page=admin_edit_membership&user_id=<?php echo $user_id; ?>" class="btn-edit-profile ma-au">Editar</a></td>
                    </tr>
                    <tr>
                        <td><h4><b>Wishlist</b></h4></td>
                        <td><a href="/wp-admin/admin.php?page=admin_wishlist&id=<?php echo $user_id; ?>" class="btn-edit-profile ma-au">Consultar</a></td>
                    </tr>
                </table>
            </div>
        </div>
        
        <?php
        
        $paged = isset($_GET['paged']) ? $_GET['paged'] : 1;
        $sort['name'] = isset($_GET['sort']) ? $_GET['sort'] : 'ID';
        $sort['order'] = isset($_GET['order']) ? $_GET['order'] : 'DESC';
        $sort_by = ' ORDER BY ' . $sort['name'] . ' '. $sort['order'];
        $link = 'admin.php?page=user_detail';
        ?>
            <h1>Historial de rentas</h1>
            <form action="<?php echo $link; ?>" method="get" style="display: none;">
                <input type="hidden" name="page" value="user_list">
                <input type="hidden" name="sort" value="<?php echo $sort['name']; ?>">
                <input type="hidden" name="order" value="<?php echo $sort['order']; ?>">
                <input type="hidden" name="paged" value="<?php echo $paged; ?>">
                <input type="submit" value="Send">
            </form>
        <?php
        
        $sql = "SELECT ".$prefix."wishlist.*, ".$prefix."posts.post_title as Game_Name FROM ".$prefix."wishlist INNER JOIN ".$prefix."posts ON ".$prefix."wishlist.product_id=".$prefix."posts.ID AND ".$prefix."wishlist.confirmed_delivery=1 WHERE user_id=".$user_id."".$sort_by;
        $rows = $wpdb->get_results($sql);
        
        $rows_per_page = 5;
 
        // add pagination arguments from WordPress
        $pagination_args = array(
            'base' => add_query_arg('paged','%#%'),
            'format' => '',
            'total' => ceil(sizeof($rows)/$rows_per_page),
            'current' => $paged,
            'show_all' => false,
            'type' => 'plain',
        );
 
        $start = ($paged - 1) * $rows_per_page;
        $end_initial = $start + $rows_per_page;
        $end = (sizeof($rows) < $end_initial) ? sizeof($rows) : $end_initial;
        
        if (count($rows) > 0) {
            // prepare link for pagination
            $link .= '&paged=' . $paged;
 
            $order = $sort['order'] == "ASC" ? "DESC" : "ASC";
        ?>
            <table id="user-sent-mail" class="wp-list-table widefat fixed users">
                <thead>
                    <tr class="manage-column">
                        <th class="col-from">
                            <a href="<?php echo $link.'&sort=&order='.$order; ?>">
                                Titulo rentado
                            </a>
                        </th>
                        <th class="col-subject">
                            <a href="<?php echo $link.'&sort=&order='.$order; ?>">
                                Consola
                            </a>
                        </th>
                        <th class="col-body">
                            <a href="<?php echo $link.'&sort=&order='.$order; ?>">
                                Fecha de rentas
                            </a>
                        </th>
                        <th class="col-created">
                            <a href="<?php echo $link.'&sort=&order='.$order; ?>">
                                Status
                            </a>
                        </th>
                        <th class="col-created">
                            <a href="<?php echo $link.'&sort=&order='.$order; ?>">
                                Fecha de devolucion
                            </a>
                        </th>
                    </tr>
                </thead>
                <tbody>
        <?php
            // add rows
            for ($index = $start; $index < $end;  ++$index) {
                $row = $rows[$index];
 
                $class_row = ($index % 2 == 1 ) ? ' class="alternate"' : '';
        ?>
                <tr <?php echo $class_row; ?>>
                    <td><?php echo $row->Game_Name; ?></a></td>
                    <td><?php echo $row->registered_date; ?></a></td>
                    <td><?php echo $row->registered_date; ?></a></td>
                    <?php if($row->is_returned==1) { ?>
                    <td>DEVUELTO</a></td>
                    <?php } else { ?>
                    <td>EN RENTA</a></td>
                    <?php } ?>
                    <td><?php echo $row->expired_date; ?></a></td>
                </tr>
        <?php
            }
        ?>
            </tbody>
        </table>
        <?php
            // add pagination links from WordPress
            echo paginate_links($pagination_args);
        
        } else {
            ?>
            <p>No records found, try again please</p>
        <?php
        } // endif count($rows)
    }
    
    function user_detail_edit() {
        $user_id = $_GET['id'];
        $user = get_user_by( 'ID', $user_id );
        $user_meta = get_user_meta ( $user_id);
        ?>
        <form style="width: 440px;" action="" method="POST" id="id_form_update_user_detail">
            <table>
                <tr>
                    <td class="text-right">Nombre(s):</td>
                    <td class="text-left">
                        <input type="hidden" name="action" value="update_user_detail">
                        <input type="hidden" name="customer_id" value="<?php echo $user_id; ?>">
                        <input type="text" value="<?php echo $user_meta['first_name'][0]; ?>" name="first_name">
                    </td>
                </tr>
                <tr>
                    <td class="text-right">Apellidos:</td>
                    <td class="text-left"><input type="text" value="<?php echo $user_meta['last_name'][0]; ?>" name="last_name"></td>
                </tr>
                <tr>
                    <td class="text-right">Fecha de nacimiento:</td>
                    <td class="text-left"><input type="text" value="<?php if(isset($user_meta['birthday'])) echo $user_meta['birthday'][0]; ?>" name="birthday"></td>
                </tr>
                <tr>
                    <td class="text-right">
                        Dirección:<br>
                        Calle:
                    </td>
                    <td class="text-left"><input type="text" value="<?php if(isset($user_meta['street'])) echo $user_meta['street'][0]; ?>" name="street"></td>
                </tr>
                <tr>
                    <td class="text-right">Número exterior:</td>
                    <td class="text-left"><input type="text" value="<?php if(isset($user_meta['outdoor_number'])) echo $user_meta['outdoor_number'][0]; ?>" name="outdoor_number"></td>
                </tr>
                <tr>
                    <td class="text-right">Número interior:</td>
                    <td class="text-left"><input type="text" value="<?php if(isset($user_meta['inner_number'])) echo $user_meta['inner_number'][0]; ?>" name="inner_number"></td>
                </tr>
                <tr>
                    <td class="text-right">Colonia:</td>
                    <td class="text-left"><input type="text" value="<?php if(isset($user_meta['cologne'])) echo $user_meta['cologne'][0]; ?>" name="cologne"></td>
                </tr>
                <tr>
                    <td class="text-right">Municipio:</td>
                    <td class="text-left"><input type="text" value="<?php if(isset($user_meta['municipio'])) echo $user_meta['municipio'][0]; ?>" name="municipio"></td>
                </tr>
                <tr>
                    <td class="text-right">Código Postal:</td>
                    <td class="text-left"><input type="text" value="<?php if(isset($user_meta['postal'])) echo $user_meta['postal'][0]; ?>" name="postal"></td>
                </tr>
                <tr>
                    <td class="text-right">Correo electrónico:</td>
                    <td class="text-left"><input type="text" value="<?php echo $user->user_email; ?>" name="user_email"></td>
                </tr>
                <tr>
                    <td class="text-right">Estado:</td>
                    <td class="text-left"><input type="text" value="<?php if(isset($user_meta['state'])) echo $user_meta['state'][0]; ?>" name="state"></td>
                </tr>
                <tr>
                    <td class="text-right">Teléfono:</td>
                    <td class="text-left"><input type="text" value="<?php if(isset($user_meta['phone'])) echo $user_meta['phone'][0]; ?>" name="phone"></td>
                </tr>
            </table>
            
            <div id="id_div_confirm_udpate_user_detail" style="display: none;">
                <h4 class="text-center">¿Estás seguro de actualizar la información?</h4>
                <div style="display: flex; width: 100%;">
                    <button class="btn-edit-profile ma-au" type="button" onclick="submitUpdateUserDetail()">Si</button>
                    <button class="btn-edit-profile ma-au" type="button" onclick="cancelUpdateUserDetail()">No</button> 
                </div>
            </div>
            <button class="btn-edit-profile ma-au" type="button" onclick="confirmUpdateUserDetail(this)" id="id_btn_actualize_user_detail">Actualizar</button>
        </form>
        <?php
    }
    
    function admin_wishlist() {
        global $wpdb;
        $prefix         = $wpdb->prefix;
        $user_id        = $_GET['id'];
        $result         = $wpdb->get_results( "SELECT ".$prefix."wishlist.*, ".$prefix."posts.ID as ID, ".$prefix."posts.post_title as Title FROM ".$prefix."wishlist LEFT JOIN ".$prefix."posts ON ".$prefix."wishlist.product_id=".$prefix."posts.ID WHERE ".$prefix."wishlist.user_id =".$user_id." Order By ".$prefix."wishlist.priority");
        $user_meta_data = get_user_meta($user_id);
        $user           = get_user_by( 'ID', $user_id );
        ?>
        <h2 style="text-align: center;">Wishlist de <?php echo $user_meta_data['first_name'][0];?> <?php echo $user_meta_data['last_name'][0];?></h2>
        <?php
            $sql = "SELECT ".$prefix."membership_types.membership_name, ".$prefix."membership_types.titles_number, ".$prefix."user_membership.registered_date, ".$prefix."user_membership.expired_date FROM ".$prefix."user_membership LEFT JOIN ".$prefix."membership_recurring_payments ON ".$prefix."user_membership.membership_option_id= ".$prefix."membership_recurring_payments.id LEFT JOIN ".$prefix."membership_types ON ".$prefix."membership_types.id=".$prefix."membership_recurring_payments.membership_id WHERE ".$prefix."user_membership.user_id=".$user_id;
            $rows = $wpdb->get_results($sql);
            if(count($rows)>0) {
                $monthEng = date("F", strtotime($rows[0]->registered_date));
                if($monthEng == "January") {
                    $monthEng = "Enero";
                } else if($monthEng == "February") {
                    $monthEng = "Febrero";
                } else if($monthEng == "March") {
                    $monthEng = "Marzo";
                } else if($monthEng == "April") {
                    $monthEng = "Abril";
                } else if($monthEng == "May") {
                    $monthEng = "Mayo";
                } else if($monthEng == "June") {
                    $monthEng = "Junio";
                } else if($monthEng == "July") {
                    $monthEng = "Julio";
                } else if($monthEng == "August") {
                    $monthEng = "Agosto";
                } else if($monthEng == "September") {
                    $monthEng = "Septiembre";
                } else if($monthEng == "October") {
                    $monthEng = "Octubre";
                } else if($monthEng == "November") {
                    $monthEng = "Noviembre";
                } else if($monthEng == "December") {
                    $monthEng = "Diciembre";
                }
                $registered_date = date("d", strtotime($rows[0]->registered_date))."/".$monthEng."/".date("Y", strtotime($rows[0]->registered_date));

                $monthEng = date("F", strtotime($rows[0]->expired_date));
                if($monthEng == "January") {
                    $monthEng = "Enero";
                } else if($monthEng == "February") {
                    $monthEng = "Febrero";
                } else if($monthEng == "March") {
                    $monthEng = "Marzo";
                } else if($monthEng == "April") {
                    $monthEng = "Abril";
                } else if($monthEng == "May") {
                    $monthEng = "Mayo";
                } else if($monthEng == "June") {
                    $monthEng = "Junio";
                } else if($monthEng == "July") {
                    $monthEng = "Julio";
                } else if($monthEng == "August") {
                    $monthEng = "Agosto";
                } else if($monthEng == "September") {
                    $monthEng = "Septiembre";
                } else if($monthEng == "October") {
                    $monthEng = "Octubre";
                } else if($monthEng == "November") {
                    $monthEng = "Noviembre";
                } else if($monthEng == "December") {
                    $monthEng = "Diciembre";
                }
                $expired_date = date("d", strtotime($rows[0]->expired_date))."/".$monthEng."/".date("Y", strtotime($rows[0]->expired_date));
        ?>
        <div style="text-align: center">
            <i><h4>Membresía: <?php echo $rows[0]->membership_name; ?></h4>
            <h4>Cantidad de videojuegos: <?php echo $rows[0]->titles_number; ?></h4>
            <h4>Vigencia: <?php echo $registered_date; ?> -  <?php echo $expired_date; ?></h4>
            <h4>Correo: <?php echo $user->user_email; ?></h4></i>
        </div>
        <?php
            }
        if(count($result) > 0) {
            $count = 0;
            for($i=0; $i<count($result); $i++) {
                $product_id         = $result[$i]->ID;
                $img_product_id     = get_post_meta( $product_id, '_thumbnail_id', true );
                $img_post           = $wpdb->get_results( "SELECT * FROM ".$prefix."posts WHERE ID = $img_product_id");
                $img_src            = $img_post[0]->guid;
                if($result[$i]->is_returned != 1) {
                    $count = $count+1;
        ?>
        <div style="max-width: 1000px; margin: auto; border: 5px solid #000; border-radius: 5px; margin-top: 10px;">
            <table>
                <tr>
                    <td style="width: 10%; text-align: center;">
                        <?php if($i>0) {?>
                        <a onclick="submitActionFormForUser('up', <?php echo $product_id; ?>, <?php echo $result[$i]->priority; ?>, <?php echo $user_id; ?>)"><img src="/wp-content/uploads/2020/10/up_rent.png" style="width:30px;"></a><br>
                        <?php } ?>
                        <?php if($i<(count($result)-1)) {?>
                        <a onclick="submitActionFormForUser('down', <?php echo $product_id; ?>, <?php echo $result[$i]->priority; ?>, <?php echo $user_id; ?>)"><img src="/wp-content/uploads/2020/10/down-rent.png" style="width:30px;"></a>
                        <?php } ?>
                    </td>
                    <td style="width: 10%; text-align: center;"><?php echo $count; ?></td>
                    <td style="width: 15%; text-align: center;"><img src="<?php echo $img_src; ?>" style="width:100%;"></td>
                    <td style="width: 50%; text-align: center;"><?php echo $result[$i]->Title; ?></td>
                    <td style="width: 15%; text-align: center;">
                        
                        <?php
                            if($result[$i]->user_approved==1 && $result[$i]->admin_approved==1) {
                        ?>
                        <a style="background: #60ff60; width: 100%; display: block; margin-top: 10px; color: white; text-align: center; padding: 5px; border-radius: 25px;" class="on-hold">Confirmar</a>
                        <?php
                            } else {
                        ?>
                        <a style="background: #1bb0ce; width: 100%; display: block; margin-top: 10px; color: white; text-align: center; padding: 5px; border-radius: 25px;" onclick="submitActionFormForUser('admin_confirm', <?php echo $product_id; ?>, 0, <?php echo $user_id; ?>)" class="on-hold">Confirmar</a>
                        <?php
                            }
                        ?>
                        
                        <?php
                            if($result[$i]->change_request==1) {
                        ?>
                        <a style="background: orange; width: 100%; display: block; margin-top: 10px; color: white; text-align: center; padding: 5px; border-radius: 25px;" onclick="confirmAdminChangeRequest('cofirmChangeRequest', <?php echo $product_id; ?>, 0, <?php echo $user_id; ?>)" class="on-hold">Proceso de cambio</a>
                        <?php
                            } else {
                        ?>
                            <?php
                                if($result[$i]->admin_approved == 1) {
                                    if($result[$i]->confirmed_delivery == 0) {
                            ?>
                            <a style="background: #1bb0ce; width: 100%; display: block; margin-top: 10px; color: white; text-align: center; padding: 5px; border-radius: 25px;" onclick="submitActionFormForUser('confirmed_delivery', <?php echo $product_id; ?>, 0, <?php echo $user_id; ?>)" class="on-hold">Entregar</a>
                            <?php
                                    } else {
                            ?>
                            <a style="background: #60ff60; width: 100%; display: block; margin-top: 10px; color: white; text-align: center; padding: 5px; border-radius: 25px;" lass="on-hold">Entregar</a>
                            <?php     
                                    }
                                }
                            ?>
                            <?php
                            }
                            ?>
                        <a href="/confirmation-of-wishlist?action=delete&product_id=<?php echo $product_id; ?>&user_id=<?php echo $user_id; ?>" style="background: #f00; width: 100%; display: block; margin-top: 10px; color: white; text-align: center; padding: 5px; border-radius: 25px;">Borrar</a>
                    </td>
                </tr>
            </table>
        </div>
        <?php
                }
            }
            if(count($result)<10) {
                ?>
                    <h4 style="margin: auto; text-align: center; margin-top: 50px; margin-bottom: 50px;">Add 10 titles to continue.</h4>
                <?php
            }
        }
        ?>
        
        <form action="" method="POST" id="id_action_form" style="display: none;"> 
            <input type="text" name="action" id="id_action">
            <input type="text" name="product_id" id="id_product">
            <input type="text" name="priority" id="id_priority">
            <input type="text" name="user_id" id="id_user" value="<?php echo $user_id;?>">
        </form>
        
        <!-- <form action="" method="POST" id="id_action_admin_confirm_form" style="display: none;"> 
            <input type="text" name="action" id="id_action" value="admin_confirm">
            <input type="text" name="user_id" id="id_user" value="<?php echo $user_id;?>">
        </form> -->

        <div id="id_div_confirm_change_request" style="left: 34%; padding: 33px; display: none; background-color: white; position: absolute; top: 28%; border-radius: 10px;">
            <h4 class="text-center">¿Está seguro de recibir el videojuego?</h4>
            <div style="display: flex; width: 100%;">
                <button class="btn-edit-profile ma-au" type="button" onclick="document.getElementById('id_action_form').submit();">Si</button>
                <button class="btn-edit-profile ma-au" type="button" onclick="document.getElementById('id_div_confirm_change_request').style.display='none';">No</button> 
            </div>
        </div>

        <?php
    }
    
    
    function admin_edit_membership() {
        global $wpdb;
        $prefix         = $wpdb->prefix;
        $user_id        = $_GET['user_id'];
        $user           = get_userdata($user_id);
        $sql            = "SELECT * FROM ".$prefix."membership_types";
        $memberships    = $wpdb->get_results($sql);
        $sql            = "SELECT * FROM ".$prefix."user_membership WHERE user_id=".$user_id;
        $current_membership_status = 0;
        $membership_results = $wpdb->get_results($sql);
        if(count($membership_results)>0) {
            $current_membership_status = $membership_results[0]->status;
        }
        
        ?>
        <h1>Edit Membership</h1>
        <?php if(isset($_GET['membership_id'])) {
            $sql = "SELECT * FROM ".$prefix."membership_recurring_payments WHERE membership_id=".$_GET['membership_id'];
            $memberships_payment_options = $wpdb->get_results($sql);
            for($i=0; $i<count($memberships_payment_options); $i++) {?>
                <a style="background: #f00; width: 200px; display: block; margin-top: 10px; color: white; text-align: center; padding: 5px; border-radius: 25px;" onclick="setAdminMembershipEditForm(<?php echo $memberships_payment_options[$i]->id; ?>)">
                    <?php echo $memberships_payment_options[$i]->monthly_frequency; ?> messes $<?php echo $memberships_payment_options[$i]->price; ?>
                </a>
            <?php } ?>
            <button class="btn-edit-profile ma-au" type="button" onclick="confirmUpdateUserDetail(this)" id="id_btn_actualize_user_detail" style="width: 150px;">Actualizar</button>
        <?php } else { 
            for($i=0; $i<count($memberships); $i++) {?>
            <a href="/wp-admin/admin.php?page=admin_edit_membership&membership_id=<?php echo $memberships[$i]->id; ?>&user_id=<?php echo $user_id; ?>" style="background: #f00; width: 200px; display: block; margin-top: 10px; color: white; text-align: center; padding: 5px; border-radius: 25px;"><?php echo $memberships[$i]->membership_name; ?></a>
            <?php } 
                if($current_membership_status==-1) {
            ?>
            <a onclick="setAdminMembershipAcOrSu(1); document.getElementById('id_div_confirm_udpate_user_detail').style.display='block';" style="background: #f00; width: 200px; display: block; margin-top: 10px; color: white; text-align: center; padding: 5px; border-radius: 25px;">Activo</a>
            <?php } else if($current_membership_status==1) { ?>
            <a onclick="setAdminMembershipAcOrSu(-1); document.getElementById('id_div_confirm_udpate_user_detail').style.display='block';" style="background: #f00; width: 200px; display: block; margin-top: 10px; color: white; text-align: center; padding: 5px; border-radius: 25px;">suspender</a>
            <?php } ?>
        <?php
        }
        ?>
            <form action="" method="POST" id="id_form_update_user_detail" style="display: none;"> 
                <input type="text" name="memberships_payment_option_id" id="id_memberships_payment_options">
                <input type="text" name="user_id" id="id_user" value="<?php echo $user_id;?>">
            </form>
            <form action="" method="POST" id="id_form_AcOSu_membership" style="display: none;"> 
                <input type="text" name="acOrsu" id="id_memberships_acOrsu_value">
                <input type="text" name="user_id" id="id_user" value="<?php echo $user_id;?>">
            </form>
            <div id="id_div_confirm_udpate_user_detail" style="display: none;">
                <h4 class="text-center">¿Estás seguro de suspender la cuenta del usuario <?php echo $user->user_login ;?>?</h4>
                <div style="display: flex; width: 100%;">
                    <button class="btn-edit-profile ma-au" type="button" onclick="document.getElementById('id_form_AcOSu_membership').submit()" style="width: 150px;">Si</button>
                    <button class="btn-edit-profile ma-au" type="button" onclick="document.getElementById('id_form_AcOSu_membership').submit()" style="width: 150px;">No</button> 
                </div>
            </div>
        <?php
    }