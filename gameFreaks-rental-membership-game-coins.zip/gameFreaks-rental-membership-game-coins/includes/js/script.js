function openCity(cityName) {
  var i;
  var x = document.getElementsByClassName("city");
  for (i = 0; i < x.length; i++) {
    x[i].style.display = "none";  
  }
  document.getElementById(cityName).style.display = "block";  
}

function confirmUpdateUserDetail(val) {
    val.style.display = "none";
    document.getElementById("id_div_confirm_udpate_user_detail").style.display = "block";
}

function submitUpdateUserDetail() {
    document.getElementById("id_form_update_user_detail").submit();
}

function cancelUpdateUserDetail() {
    document.getElementById("id_div_confirm_udpate_user_detail").style.display = "none";
    document.getElementById("id_btn_actualize_user_detail").style.display = "block";
}

function submitActionForm(action, product_id, priority) {
    document.getElementById("id_action").value = action;
    document.getElementById("id_product").value = product_id;
    document.getElementById("id_priority").value = priority;
    
    document.getElementById("id_action_form").submit();
}

function submitActionFormForUser(action, product_id, priority, user_id) {
    document.getElementById("id_action").value = action;
    document.getElementById("id_product").value = product_id;
    document.getElementById("id_priority").value = priority;
    document.getElementById("id_user").value = user_id;
    document.getElementById("id_action_form").submit();
}

function setAdminMembershipEditForm(membership_option_id) {
    document.getElementById("id_memberships_payment_options").value = membership_option_id;
}

function setAdminMembershipAcOrSu(val) {
    document.getElementById("id_memberships_acOrsu_value").value = val;
}

function editMembership() {
    var paypal_code = document.getElementById("paypal_code").value;
    console.log(paypal_code);

    if(paypal_code.includes("<script")) {
        paypal_code = paypal_code.replace("<script", "startscript");
        paypal_code = paypal_code.replace("<script", "startscript");
        paypal_code = paypal_code.replace("</script>", "endscript");
        paypal_code = paypal_code.replace("</script>", "endscript");
        document.getElementById("paypal_code").value = paypal_code;
    }

    console.log(document.getElementById("id_edit_recurring_payment_form"));
    setTimeout(() => {
        document.getElementById("id_edit_recurring_payment_form").submit();
    }, 1000);
    
}

function searchRents() {
    console.log("ddddddddddddd");
}

function confirmAdminChangeRequest(action, product_id, priority, user_id) {
    document.getElementById("id_action").value      = action;
    document.getElementById("id_product").value     = product_id;
    document.getElementById("id_priority").value    = priority;
    document.getElementById("id_user").value        = user_id;
    document.getElementById("id_div_confirm_change_request").style.display="block";
}