<?php
    function games_in_stock() {
        ?>
            <h1>Juegos en stock</h1>
        <?php
    }