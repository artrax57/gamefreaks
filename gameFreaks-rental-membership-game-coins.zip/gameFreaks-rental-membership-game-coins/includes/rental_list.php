<?php
    function rental_list() {
        ?>
            <h1>Lista de rentas</h1>
        <?php
        global $wpdb;
        $prefix = $wpdb->prefix;
        

        $paged = isset($_GET['paged']) ? $_GET['paged'] : 1;
        $sort['name'] = isset($_GET['sort']) ? $_GET['sort'] : 'ID';
        $sort['order'] = isset($_GET['order']) ? $_GET['order'] : 'DESC';
        $sort_by = ' ORDER BY ' . $sort['name'] . ' '. $sort['order'];
        $link = 'admin.php?page=rental_list';

        ?>

        <form action="<?php echo $link; ?>" method="get" style="display: none;">
            <input type="hidden" name="page" value="user_list">
            <input type="hidden" name="sort" value="<?php echo $sort['name']; ?>">
            <input type="hidden" name="order" value="<?php echo $sort['order']; ?>">
            <input type="hidden" name="paged" value="<?php echo $paged; ?>">
            <input type="submit" value="Send">
        </form>

        <?php
        
        $sql = "SELECT wpky_users.ID as USER_ID, wpky_users.user_email as USER_EMAIL, wpky_posts.post_title as TITLE, wpky_wishlist.registered_date as RENT_DATE, 
                        wpky_wishlist.expired_date as EXPIRED_DATE, wpky_wishlist.product_id as PRODUCT_ID, wpky_wishlist.confirmation_code as CON_CODE
                FROM wpky_users RIGHT JOIN wpky_wishlist ON wpky_users.ID=wpky_wishlist.user_id LEFT JOIN wpky_posts ON wpky_posts.ID=wpky_wishlist.product_id 
                WHERE wpky_wishlist.confirmed_delivery=1";
        $rows = $wpdb->get_results($sql);
        $rows_per_page = 50;
 
        // add pagination arguments from WordPress
        $pagination_args = array(
            'base'      => add_query_arg('paged','%#%'),
            'format'    => '',
            'total'     => ceil(sizeof($rows)/$rows_per_page),
            'current'   => $paged,
            'show_all'  => false,
            'type'      => 'plain',
        );
 
        $start = ($paged - 1) * $rows_per_page;
        $end_initial = $start + $rows_per_page;
        $end = (sizeof($rows) < $end_initial) ? sizeof($rows) : $end_initial;
        
        if (count($rows) > 0) {
            // prepare link for pagination
            $link .= '&paged=' . $paged;
            $order = $sort['order'] == "ASC" ? "DESC" : "ASC";
        ?>
        <table id="user-sent-mail" class="wp-list-table widefat fixed users">
            <thead>
                <tr class="manage-column">
                    <th class="col-from">
                        <input type="text" name="full_name" style="width: 100% !important;" onkeyup="searchRents()">
                    </th>
                    <th class="col-subject">
                        <input type="text" name="email"     style="width: 100% !important;" onkeyup="searchRents()">
                    </th>
                    <th class="col-body">
                        <input type="text" name="title"     style="width: 100% !important;" onkeyup="searchRents()">
                    </th>
                    <th class="col-created">
                        <input type="text" name="category"  style="width: 100% !important;" onkeyup="searchRents()">
                    </th>
                    <th class="col-created">
                        <input type="text" name="rent_date" style="width: 100% !important;" onkeyup="searchRents()">
                    </th>
                    <th class="col-created">
                        <input type="text" name="full_name" style="width: 100% !important;" onkeyup="searchRents()">
                    </th>
                    <th class="col-created">
                        <input type="text" name="full_name" style="width: 100% !important;" onkeyup="searchRents()">
                    </th>
                    <th class="col-created">
                        <input type="text" name="full_name" style="width: 100% !important;" onkeyup="searchRents()">
                    </th>
                </tr>
                <tr class="manage-column">
                    <th class="col-from">
                        <a href="<?php echo $link.'&sort=&order='.$order; ?>">
                            Nombre
                        </a>
                    </th>
                    <th class="col-subject">
                        <a href="<?php echo $link.'&sort=&order='.$order; ?>">
                            Correo electr&#xF3;nico
                        </a>
                    </th>
                    <th class="col-subject">
                        <a href="<?php echo $link.'&sort=&order='.$order; ?>">
                            T&#xED;tulo
                        </a>
                    </th>
                    <th class="col-body">
                        <a href="<?php echo $link.'&sort=&order='.$order; ?>">
                            Consola
                        </a>
                    </th>
                    <th class="col-created">
                        <a href="<?php echo $link.'&sort=&order='.$order; ?>">
                            Fecha de renta
                        </a>
                    </th>
                    <th class="col-created">
                        <a href="<?php echo $link.'&sort=&order='.$order; ?>">
                            Status
                        </a>
                    </th>
                    <th class="col-created">
                        <a href="<?php echo $link.'&sort=&order='.$order; ?>">
                            Fecha de devolución
                        </a>
                    </th>
                    <th class="col-created">
                        <a href="<?php echo $link.'&sort=&order='.$order; ?>">
                            Código de confirmaci
                        </a>
                    </th>
                </tr>
            </thead>
            <tbody>
            <?php
            // add rows
            for ($index = $start; $index < $end;  ++$index) {
                $row        = $rows[$index];
                $class_row  = ($index % 2 == 1 ) ? ' class="alternate"' : '';
                $user_id    = $row->USER_ID;
                $fullName   = get_user_meta( $user_id, 'first_name', true )." ".get_user_meta( $user_id, 'last_name', true );
                $product_id = $row->PRODUCT_ID;
                $terms      = get_the_terms( $product_id, 'product_cat' );
                $category   = "";
                for($j=0; $j<count($terms); $j++) {
                    $category .= $terms[$j]->name." ";
                }
            ?>
                <tr <?php echo $class_row; ?>>
                    <td><?php echo $fullName; ?></td>
                    <td><?php echo $row->USER_EMAIL; ?></td>
                    <td><?php echo $row->TITLE; ?></td>
                    <td><?php echo $category; ?></td>
                    <td><?php echo $row->RENT_DATE; ?></td>
                    <td>
                        <?php
                            if(!empty($row->EXPIRED_DATE)) {
                                echo "DEVUELTO";
                            } else {
                                echo "EN RENTA";
                            }
                        ?>
                    </td>
                    <td><?php echo $row->EXPIRED_DATE; ?></td>
                    <td><?php echo $row->CON_CODE; ?></td>
                </tr>
            <?php
            }
            ?>
            </tbody>
        </table>
        <?php
        }
    }