<?php
/**
 *  Functions and definitions for auxin framework
 *
 * 
 * @package    Auxin
 * @author     averta (c) 2014-2020
 * @link       http://averta.net
 */

/*-----------------------------------------------------------------------------------*/
/*  Add your custom functions here -  We recommend you to use "code-snippets" plugin instead
/*  https://wordpress.org/plugins/code-snippets/
/*-----------------------------------------------------------------------------------*/


// your code here


/*-----------------------------------------------------------------------------------*/
/*  Init theme framework
/*-----------------------------------------------------------------------------------*/
require( 'auxin/auxin-include/auxin.php' );
/*-----------------------------------------------------------------------------------*/

function wooc_save_extra_register_fields( $customer_id ) {
    if ( isset( $_POST['nombre'] ) ) {
        // Phone input filed which is used in WooCommerce
        update_user_meta( $customer_id, 'first_name', sanitize_text_field( $_POST['nombre'] ) );
        update_user_meta( $customer_id, 'last_name', sanitize_text_field( $_POST['apellidos'] ) );
        update_user_meta( $customer_id, 'birthday', sanitize_text_field( $_POST['nacimiento'] ) );
        update_user_meta( $customer_id, 'street', sanitize_text_field( $_POST['calle'] ) );
        update_user_meta( $customer_id, 'inner_number', sanitize_text_field( $_POST['interior'] ) );
        update_user_meta( $customer_id, 'outdoor_number', sanitize_text_field( $_POST['apellidos'] ) );
        update_user_meta( $customer_id, 'cologne', sanitize_text_field( $_POST['colonia'] ) );
        update_user_meta( $customer_id, 'municipio', sanitize_text_field( $_POST['municipio'] ) );
        update_user_meta( $customer_id, 'postal', sanitize_text_field( $_POST['postal'] ) );
        update_user_meta( $customer_id, 'state', sanitize_text_field( $_POST['estado'] ) );
        update_user_meta( $customer_id, 'address_reference', sanitize_text_field( $_POST['domicilio'] ) );
        update_user_meta( $customer_id, 'between_which_streets', sanitize_text_field( $_POST['fachada'] ) );
        update_user_meta( $customer_id, 'phone', sanitize_text_field( $_POST['phone'] ) );
        if(! empty( $_POST['referal'])) {
            update_user_meta( $customer_id, 'referal', sanitize_text_field( $_POST['referal'] ) );
        }
        
        $user    = get_userdata( $customer_id );
		$user_meta  = get_user_meta($customer_id);
		
		$to_admin = "contacto@gamefreaks.com.mx";
		$to_admin_subject = "Nuevo usuario en Gamefreaks";
		$user_data = "";
		$user_data .= "<table>";
        $user_data .= "            <tr>";
        $user_data .= "                <td class='text-right'>Nombre(s):</td>";
        $user_data .= "                <td class='text-left'>".$user_meta['first_name'][0]."</td>";
        $user_data .= "            </tr>";
        $user_data .= "            <tr>";
        $user_data .= "                <td class='text-right'>Apellidos:</td>";
        $user_data .= "                <td class='text-left'>".$user_meta['last_name'][0]."</td>";
        $user_data .= "            </tr>";
        $user_data .= "            <tr>";
        $user_data .= "                <td class='text-right'>Fecha de nacimiento:</td>";
        $user_data .= "                <td class='text-left'>".$user_meta['birthday'][0]."</td>";
        $user_data .= "            </tr>";
        $user_data .= "            <tr>";
        $user_data .= "                <td class='text-right'>";
        $user_data .= "                    Dirección:<br>";
        $user_data .= "                    Calle:";
        $user_data .= "                </td>";
        $user_data .= "                <td class='text-left'>".$user_meta['street'][0]."</td>";
        $user_data .= "            </tr>";
        $user_data .= "            <tr>";
        $user_data .= "                <td class='text-right'>Número exterior:</td>";
        $user_data .= "                <td class='text-left'>".$user_meta['outdoor_number'][0]."</td>";
        $user_data .= "            </tr>";
        $user_data .= "            <tr>";
        $user_data .= "                <td class='text-right'>Número interior:</td>";
        $user_data .= "                <td class='text-left'>".$user_meta['inner_number'][0]."</td>";
        $user_data .= "            </tr>";
        $user_data .= "            <tr>";
        $user_data .= "                <td class='text-right'>Colonia:</td>";
        $user_data .= "                <td class='text-left'>".$user_meta['cologne'][0]."</td>";
        $user_data .= "            </tr>";
        $user_data .= "            <tr>";
        $user_data .= "                <td class='text-right'>Municipio:</td>";
        $user_data .= "                <td class='text-left'>".$user_meta['municipio'][0]."</td>";
        $user_data .= "            </tr>";
        $user_data .= "            <tr>";
        $user_data .= "                <td class='text-right'>Código Postal:</td>";
        $user_data .= "                <td class='text-left'>".$user_meta['postal'][0]."</td>";
        $user_data .= "            </tr>";
        $user_data .= "            <tr>";
        $user_data .= "                <td class='text-right'>Estado:</td>";
        $user_data .= "                <td class='text-left'>".$user_meta['state'][0]."</td>";
        $user_data .= "            </tr>";
        $user_data .= "            <tr>";
        $user_data .= "                <td class='text-right'>Teléfono:</td>";
        $user_data .= "                <td class='text-left'>".$user_meta['phone'][0]."</td>";
        $user_data .= "            </tr>";
        $user_data .= "        </table>";
        $user_data .= "Registro el ".$user->user_registered." desde la página de Gamefreaks.com";
		$res_admin     = wp_mail( $to_admin, $to_admin_subject, $user_data, "Content-Type: text/html\r\n" );
		$res_admin     = wp_mail( "todayforfuture@outlook.com", $to_admin_subject, $user_data, "Content-Type: text/html\r\n" );
    }
    if ( isset( $_POST['apellidos'] ) ) {
        //First name field which is by default
        
    }
    if ( isset( $_POST['billing_last_name'] ) ) {
         // Last name field which is by default
         update_user_meta( $customer_id, 'last_name', sanitize_text_field( $_POST['billing_last_name'] ) );
         // Last name field which is used in WooCommerce
         update_user_meta( $customer_id, 'billing_last_name', sanitize_text_field( $_POST['billing_last_name'] ) );
    }
}
add_action( 'woocommerce_created_customer', 'wooc_save_extra_register_fields' );

if(isset($_GET['rent_product_id'])) {
    global $wpdb;
    $prefix = $wpdb->prefix;
    $user_id = get_current_user_id();
    $product_id = $_GET['rent_product_id'];
    
    $result = $wpdb->get_results( "SELECT * FROM ".$prefix."wishlist WHERE is_returned=0 AND user_id = $user_id");
    $priority = (($wpdb->get_results( "SELECT MAX(priority) as priority FROM ".$prefix."wishlist WHERE user_id = $user_id"))[0]->priority)+1;
    if(count($result)<10) {
        $check_exist = $wpdb->get_results( "SELECT * FROM ".$prefix."wishlist WHERE user_id = $user_id AND product_id = $product_id");
        if(count($check_exist)==0) {
            $registered_date = date("Y-m-d");
            $wpdb->insert($prefix.'wishlist',array('user_id'=>$user_id,'product_id'=>$product_id, 'registered_date'=>$registered_date, 'admin_approved'=>0, 'priority'=>$priority));
            wp_redirect("confirmation-of-wishlist");
            exit();
        } else {
            echo "<script>alert('This videogame is already in your request list!');</script>";
            wp_redirect("/shop/");
            exit();
        }
    } else {
        echo "<script>alert('You can not rent more!');</script>";
        wp_redirect("confirmation-of-wishlist");
        exit();
    }
    
}

if(isset($_POST['action']) && isset($_POST['product_id'])) {
    global $wpdb;
    $prefix             = $wpdb->prefix;
    $action             = $_POST['action'];
    $product_id         = $_POST['product_id'];
    $user_id            = $_POST['user_id'];
    $current_priority   = $_POST['priority'];
    $user_data          = get_userdata($user_id);
    $user_meta          = get_user_meta($user_id);
    if($action == "up") {
        $result = $wpdb->get_results( "SELECT * FROM ".$prefix."wishlist WHERE user_id =".$user_id." ORDER BY priority");
        for($i=0; $i<count($result); $i++) {
            if($result[$i]->priority == $current_priority) {
                $wpdb->query("UPDATE ".$prefix."wishlist SET priority =".$current_priority." WHERE id =".$result[$i-1]->id);
                $wpdb->query("UPDATE ".$prefix."wishlist SET priority =".($current_priority-1)." WHERE id =".$result[$i]->id);
            }
        }
    } else if($action == "down") {
        $result = $wpdb->get_results( "SELECT * FROM ".$prefix."wishlist WHERE user_id =".$user_id." ORDER BY priority");
        for($i=0; $i<count($result); $i++) {
            if($result[$i]->priority == $current_priority) {
                $sql= "UPDATE ".$prefix."wishlist SET priority =".$current_priority." WHERE id =".$result[$i+1]->id;
                $wpdb->query($sql);
                $sql = "UPDATE ".$prefix."wishlist SET priority =".($current_priority+1)." WHERE id =".$result[$i]->id;
                $wpdb->query($sql);
            }
        }
    } else if($action == "user_confirm") {
        $returned_games = $wpdb->get_results( "SELECT * FROM ".$prefix."wishlist WHERE is_returned=1 AND user_id =".$user_id." ORDER BY priority");
        $new_games = $wpdb->get_results( "SELECT * FROM ".$prefix."wishlist WHERE user_approved=0 AND user_id =".$user_id." ORDER BY priority");

        if(count($returned_games)>0) {
            $rand = $returned_games[0]->confirmation_code;
        } else {
            while(1) {
                $seed = str_split('abcdefghijklmnopqrstuvwxyz'
                .'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
                .'0123456789'); // and any other characters
                shuffle($seed); // probably optional since array_is randomized; this may be redundant
                $rand = '';
                foreach (array_rand($seed, 10) as $k) $rand .= $seed[$k];
    
                $exist_confirmation_code = $wpdb->get_results( "SELECT * FROM ".$prefix."wishlist WHERE confirmation_code='".$rand."'");
                if(count($exist_confirmation_code) == 0) 
                    break;
            }
        }
        
        $wpdb->query("UPDATE ".$prefix."wishlist SET user_approved = 1, confirmation_code='".$rand."' WHERE user_id =".$user_id);
        
        $toUserEmail .= "<p>Confirmación de rentas:</p><table>";
        $new_games_list = "<p>El usuario ".$user_data->user_login." ha enviado la siguiente lista de títulos que desea jugar:</p><table>";
        for($i=0; $i<count($new_games); $i++) {
            $game_id = $new_games[$i]->product_id;
            $game_title = ($wpdb->get_results( "SELECT post_title FROM ".$prefix."posts WHERE ID=".$game_id))[0]->post_title;
            
            $new_games_list .= "<tr><td>".($i+1)." .</td><td>".$game_title."</td></tr>";
            $toUserEmail .= "<tr><td>".($i+1)." .</td><td>".$game_title."</td></tr>";
        }
        $new_games_list     .= "</table><p>El usuario ".$user_data->user_login." tiene los siguientes datos de contacto:</p>";
        $new_games_list     .= "<table>";
        $new_games_list     .= "<tr><td>Nombre: </td><td>".$user_meta['first_name'][0]." ".$user_meta['last_name'][0]."</td></tr>";
        $new_games_list     .= "<tr><td>Teléfono: </td><td>".$user_meta['phone'][0]."</td></tr>";
        $new_games_list     .= "<tr><td>Email: </td><td>".$user_data->user_email."</td></tr>";
        $new_games_list     .= "<tr><td>Dirección: </td><td>".$user_meta['street'][0]."</td></tr></table>";
        $new_games_list     .= "<p>Correo de confirmación generado desde gamefreaks.com</p>";
        
        $toUserEmail        .= "</table><p>En breve, personal de Gamefreaks se pondrá en contacto contigo para";
        $toUserEmail        .= "agendar una cita en relación a la entrega de tus rentas.</p>";
        $toUserEmail        .= "<p>CÓDIGO DE CONFIRMACIÓN: ".$rand."</p>";
        $toUserEmail        .= "<p>Muchas gracias por rentar en Gamefreaks.</p>";
        $toUserEmail        .= "<p>Atentamente:</p>";
        $toUserEmail        .= "<p>Ivan</p>";
        $toUserEmail        .= "<p>Director General Gamefreaks</p>";

        $to_admin_subject   = "Nueva wishlist del usuario ".$user_data->user_login;
        $to_user_subject    = "Hola ".$user_data->user_login;
        $res_admin          = wp_mail( "contacto@gamefreaks.com.mx", $to_admin_subject, $new_games_list, "Content-Type: text/html\r\n" );
        $res_admin          = wp_mail( "todayforfuture@outlook.com", $to_admin_subject, $new_games_list, "Content-Type: text/html\r\n" );

        
        $res_user          = wp_mail( $user_data->user_email, $to_user_subject, $toUserEmail, "Content-Type: text/html\r\n" );
        $res_user          = wp_mail( "todayforfuture@outlook.com", $to_user_subject, $toUserEmail, "Content-Type: text/html\r\n" );
        
        wp_redirect("/confirmation-of-wishlist/");
        exit();
    } else if($action == "admin_confirm") {
        $wpdb->query("UPDATE ".$prefix."wishlist SET admin_approved = 1 WHERE user_id =".$user_id." AND product_id=".$product_id);
    } else if($action == "confirmed_delivery") {
        $delivered_date = date("Y-m-d");
        $wpdb->query("UPDATE ".$prefix."wishlist SET confirmed_delivery = 1, delivered_date = '".$delivered_date."' WHERE user_id =".$user_id." AND product_id=".$product_id);
    } else if($action == "cofirmChangeRequest") {
        $expired_date = date("Y-m-d H:i:s");
        $wpdb->query("UPDATE ".$prefix."wishlist SET is_returned = 1, expired_date='".$expired_date."' WHERE user_id =".$user_id." AND product_id=".$product_id);
        wp_redirect("/wp-admin/admin.php?page=admin_wishlist&id=".$user_id);
        exit();
    }

    else if($action == "request_change") {
        wp_redirect("/cambiar?product_id=".$product_id);
        exit();
    }
    
    else if($action == "request_change_done") {
        $wpdb->query("UPDATE ".$prefix."wishlist SET change_request = 1 WHERE user_id =".$user_id." AND product_id=".$product_id);
        $new_games = $wpdb->get_results( "SELECT * FROM ".$prefix."wishlist WHERE change_request=1 AND user_id =".$user_id." ORDER BY priority");
        $new_games_list = "<p>Solicitud de cambio de videojuego</p><table>";
        for($i=0; $i<count($new_games); $i++) {
            $game_id = $new_games[$i]->product_id;
            $game_title = ($wpdb->get_results( "SELECT post_title FROM ".$prefix."posts WHERE ID=".$game_id))[0]->post_title;
            
            $new_games_list .= "<tr><td>".($i+1)." .</td><td>".$game_title."</td></tr>";
        }
        $new_games_list .= "</table><p>El usuario ".$user_data->user_login." desea cambiar su videojuego.</p><p>Esta es su lista actual de deseos.</p>";
        $new_games_list .= "<table>";
        $new_games_list .= "<tr><td>Nombre: </td><td>".$user_meta['first_name'][0]." ".$user_meta['last_name'][0]."</td></tr>";
        $new_games_list .= "<tr><td>Teléfono: </td><td>".$user_meta['phone'][0]."</td></tr>";
        $new_games_list .= "<tr><td>Email: </td><td>".$user_data->user_email."</td></tr>";
        $new_games_list .= "<tr><td>Dirección: </td><td>".$user_meta['street'][0]."</td></tr></table>";
        $new_games_list .= "<p>Correo de confirmación generado desde gamefreaks.com</p>";
        
        $to_admin_subject = "Solicitud de cambio de videojuego";
        $res_admin     = wp_mail( "contacto@gamefreaks.com.mx", $to_admin_subject, $new_games_list, "Content-Type: text/html\r\n" );
        $res_admin     = wp_mail( "todayforfuture@outlook.com", $to_admin_subject, $new_games_list, "Content-Type: text/html\r\n" );
        
        wp_redirect("/cambiar?product_id=".$product_id);
        exit();
    }
}

if(isset($_GET['action']) && $_GET['action']=="delete") {
    global $wpdb;
    $prefix = $wpdb->prefix;
    $action             = $_GET['action'];
    $product_id         = $_GET['product_id'];
    $user_id            = $_GET['user_id'];
    if($action == "delete") {
        $wpdb->query('DELETE FROM '.$prefix.'wishlist WHERE user_id = '.$user_id.' and product_id='.$product_id);
    }
}

if(isset($_POST['action']) && $_POST['action']=="update_user_detail") {
    global $wpdb;
    $prefix = $wpdb->prefix;
    $customer_id = $_POST['customer_id'];
    update_user_meta( $customer_id, 'first_name'            , sanitize_text_field( $_POST['first_name'] ) );
    update_user_meta( $customer_id, 'last_name'             , sanitize_text_field( $_POST['last_name'] ) );
    update_user_meta( $customer_id, 'birthday'              , sanitize_text_field( $_POST['birthday'] ) );
    update_user_meta( $customer_id, 'street'                , sanitize_text_field( $_POST['street'] ) );
    update_user_meta( $customer_id, 'inner_number'          , sanitize_text_field( $_POST['inner_number'] ) );
    update_user_meta( $customer_id, 'outdoor_number'        , sanitize_text_field( $_POST['outdoor_number'] ) );
    update_user_meta( $customer_id, 'cologne'               , sanitize_text_field( $_POST['cologne'] ) );
    update_user_meta( $customer_id, 'municipio'             , sanitize_text_field( $_POST['municipio'] ) );
    update_user_meta( $customer_id, 'postal'                , sanitize_text_field( $_POST['postal'] ) );
    update_user_meta( $customer_id, 'state'                 , sanitize_text_field( $_POST['state'] ) );
    update_user_meta( $customer_id, 'address_reference'     , sanitize_text_field( $_POST['address_reference'] ) );
    update_user_meta( $customer_id, 'between_which_streets' , sanitize_text_field( $_POST['between_which_streets'] ) );
    update_user_meta( $customer_id, 'phone'                 , sanitize_text_field( $_POST['phone'] ) );
    
    if ( !empty( $_POST['user_email'] ) ){
        if (!is_email(sanitize_email( $_POST['user_email'] ))) {
            $error[] = __('The Email you entered is not valid.  please try again.', 'profile');
        } elseif( email_exists(sanitize_email( $_POST['email'] )) != $user_id ) {
            $error[] = __('This email is already used by another user.  try a different one.', 'profile');
        } else {
            wp_update_user( array ('ID' => $customer_id, 'user_email' => sanitize_email( $_POST['user_email'] )));
        }
    }

    wp_redirect("/wp-admin/admin.php?page=user_detail&id=".$customer_id);
    exit();
}

if(isset($_POST['purchase_membership'])) {
    $payment_option = $_POST['payment_option'];
    $payment_method = $_POST['payment_method'];
    $user_id        = $_POST['user_id'];
    
    $membership = $wpdb->get_results( "SELECT * FROM ".$prefix."membership_recurring_payments WHERE id = $payment_option");
    $membership_duration = $membership[0]->monthly_frequency;
    $registered_date = date("Y-m-d");
    if($membership_duration == 12) {
        $expired_date = date('Y-m-d', strtotime($registered_date. ' + 1 year'));
    } else {
        $expired_date = date('Y-m-d', strtotime($registered_date. ' + ' .$membership_duration. ' month'));
    }

    $exist_memberships = $wpdb->get_results( "SELECT * FROM ".$prefix."user_membership WHERE user_id =".$user_id);
    if(count($exist_memberships) == 0) {
        $wpdb->insert($prefix.'user_membership',array('user_id'=>$user_id, 'membership_option_id'=>$payment_option, 'registered_date'=>$registered_date, 'payment_method'=>$payment_method, 'expired_date'=>$expired_date, 'status'=>1));
    } else {
        $wpdb->query("UPDATE ".$prefix."user_membership SET membership_option_id=".$payment_option.", registered_date='".$registered_date."', payment_method='".$payment_method."', expired_date='".$expired_date."', status=1, is_paid=0 WHERE user_id =".$user_id);
    }
    
    wp_redirect("/payment?id=".$user_id);
    exit();
}

if(isset($_POST['memberships_payment_option_id'])) {
    $payment_option = $_POST['memberships_payment_option_id'];
    $user_id        = $_POST['user_id'];
    
    if($payment_option == -1) {
        $wpdb->query("UPDATE ".$prefix."user_membership SET status = ".$payment_option." WHERE user_id =".$user_id);
    } else {
        $wpdb->query("UPDATE ".$prefix."user_membership SET membership_option_id = ".$payment_option." WHERE user_id =".$user_id);
    }
    
    wp_redirect("/wp-admin/admin.php?page=user_detail&id=".$user_id);
}

if(isset($_POST['acOrsu'])) {
    $status         = $_POST['acOrsu'];
    $user_id        = $_POST['user_id'];
    
    $wpdb->query("UPDATE ".$prefix."user_membership SET status = ".$status." WHERE user_id =".$user_id);
    
    wp_redirect("/wp-admin/admin.php?page=user_detail&id=".$user_id);
}

if(isset($_POST['add_credit_card'])) {
    $user_id    = $_POST['user_id'];
    $cardname   = $_POST['cardname'];
    $cardnum    = $_POST['cardnum'];
    $cardexp    = $_POST['cardexp'];
    $cardcvv    = $_POST['cardcvv'];
    $wpdb->insert($prefix.'user_credit_card',array('user_id'=>$user_id,'card_number'=>$cardnum, 'card_exp'=>$cardexp, 'card_cvv'=>$cardcvv, 'card_name'=>$cardname));
}

function wooc_extra_register_fields() {?>
    <input type="hidden" class="input-text" name="referal" id="referal" value="<?php if ( ! empty( $_GET['referal']) ) esc_attr_e( $_GET['referal'] ); ?>"/>
    <p class="form-row form-row-wide">
        <label for="reg_billing_phone"><b><?php _e( 'Nombre(s)', 'woocommerce' ); ?></b><span class="required">*</span></label>
        <input type="text" class="input-text" name="nombre" id="nombre" value="<?php if ( ! empty( $_POST['nombre'] ) ) esc_attr_e( $_POST['nombre'] ); ?>" required/>
    </p>
    <p class="form-row form-row-wide">
       <label for="reg_billing_first_name"><b><?php _e( 'Apellidos: ', 'woocommerce' ); ?></b><span class="required">*</span></label>
       <input type="text" class="input-text" name="apellidos" id="apellidos" value="<?php if ( ! empty( $_POST['apellidos'] ) ) esc_attr_e( $_POST['apellidos'] ); ?>" required/>
    </p>
    <p class="form-row form-row-wide">
       <label for="reg_billing_last_name"><b><?php _e( 'Fecha de nacimiento:', 'woocommerce' ); ?></b><span class="required">*</span></label>
       <input type="date" class="input-text" name="nacimiento" value="<?php if ( ! empty( $_POST['nacimiento'] ) ) esc_attr_e( $_POST['nacimiento'] ); ?>" required/>
    </p>
    <p class="form-row form-row-wide">
	    <label for="reg_billing_last_name"><b><?php _e( 'Domicilio', 'woocommerce' ); ?></b><span class="required"></span></label>
	    <label for="reg_billing_last_name"><b><?php _e( 'Servicio para usuarios ubicados en Nuevo León', 'woocommerce' ); ?></b><span class="required"></span></label>

       <label for="reg_billing_last_name"><b><?php _e( 'Calle:', 'woocommerce' ); ?></b><span class="required">*</span></label>
       <input type="text" class="input-text" name="calle" id="calle" value="<?php if ( ! empty( $_POST['calle'] ) ) esc_attr_e( $_POST['calle'] ); ?>" required/>
    </p>
    <p class="form-row form-row-wide">
       <label for="reg_billing_last_name"><b><?php _e( 'Número exterior:', 'woocommerce' ); ?></b><span class="required">*</span></label>
       <input type="text" class="input-text" name="exterior" id="exterior" value="<?php if ( ! empty( $_POST['exterior'] ) ) esc_attr_e( $_POST['exterior'] ); ?>" required />
    </p>
    <p class="form-row form-row-wide">
       <label for="reg_billing_last_name"><b><?php _e( 'Número interior:', 'woocommerce' ); ?></b></label>
       <input type="text" class="input-text" name="interior" id="interior" value="<?php if ( ! empty( $_POST['interior'] ) ) esc_attr_e( $_POST['interior'] ); ?>" />
    </p>
    <p class="form-row form-row-wide">
       <label for="reg_billing_last_name"><b><?php _e( 'Colonia:', 'woocommerce' ); ?></b><span class="required">*</span></label>
       <input type="text" class="input-text" name="colonia" id="reg_billing_last_name" value="<?php if ( ! empty( $_POST['colonia'] ) ) esc_attr_e( $_POST['colonia'] ); ?>" required/>
    </p>
    <p class="form-row form-row-wide">
       <label for="reg_billing_last_name"><b><?php _e( 'Municipio:', 'woocommerce' ); ?></b><span class="required">*</span></label>
       <input type="text" class="input-text" name="municipio" id="municipio" value="<?php if ( ! empty( $_POST['municipio'] ) ) esc_attr_e( $_POST['municipio'] ); ?>" required/>
    </p>
    <p class="form-row form-row-wide">
       <label for="reg_billing_last_name"><b><?php _e( 'Código Postal:', 'woocommerce' ); ?></b><span class="required">*</span></label>
       <input type="text" class="input-text" name="postal" id="postal" value="<?php if ( ! empty( $_POST['postal'] ) ) esc_attr_e( $_POST['postal'] ); ?>" required/>
    </p>
    <p class="form-row form-row-wide">
       <label for="reg_billing_last_name"><b><?php _e( 'Estado', 'woocommerce' ); ?></b><span class="required">*</span></label>
       <select id="estado" name="estado">
            <option value="Nuevo Leon">Nuevo León</option>
  </select>
    </p>
    <p class="form-row form-row-wide">
       <label for="reg_billing_last_name"><b><?php _e( 'Referencias del domicilio(color, fachada, algún local cercano, descripción de casa cercanas):', 'woocommerce' ); ?></b><span class="required">*</span></label>
       <input type="text" class="input-text" name="domicilio" id="domicilio" value="<?php if ( ! empty( $_POST['domicilio'] ) ) esc_attr_e( $_POST['domicilio'] ); ?>" required/>
    </p>
    <p class="form-row form-row-wide">
       <label for="reg_billing_last_name"><b><?php _e( 'Entre que calles:', 'woocommerce' ); ?></b><span class="required">*</span></label>
       <input type="text" class="input-text" name="fachada" id="fachada" value="<?php if ( ! empty( $_POST['fachada'] ) ) esc_attr_e( $_POST['fachada'] ); ?>" required/>
    </p>
    <p class="form-row form-row-wide">
       <label for="reg_billing_last_name"><b><?php _e( 'Teléfono: ', 'woocommerce' ); ?></b><span class="required">*</span></label>
       <input type="text" class="input-text" name="phone" id="reg_billing_last_name" value="<?php if ( ! empty( $_POST['teléfono'] ) ) esc_attr_e( $_POST['teléfono'] ); ?>" required/>
    </p>
    <div class="clear"></div>
    
    <?php
}






add_action( 'woocommerce_register_form_start', 'wooc_extra_register_fields' );
 
// Add the code below to your theme's functions.php file to add a confirm password field on the register form under My Accounts.
add_filter('woocommerce_registration_errors', 'registration_errors_validation', 10,3);
function registration_errors_validation($reg_errors, $sanitized_user_login, $user_email) {
    global $woocommerce;
    extract( $_POST );
    if ( strcmp( $password, $password2 ) !== 0 ) {
        return new WP_Error( 'registration-error', __( 'Passwords do not match.', 'woocommerce' ) );
    }
    return $reg_errors;
}

add_action( 'woocommerce_register_form', 'wc_register_form_password_repeat' );
function wc_register_form_password_repeat() {
    ?>
    <p class="form-row form-row-wide">
        <label for="reg_password2"><b><?php _e( 'Confirmar contraseña', 'woocommerce' ); ?> </b><span class="required">*</span></label>
        <input type="password" class="input-text" name="password2" id="reg_password2" value="<?php if ( ! empty( $_POST['password2'] ) ) echo esc_attr( $_POST['password2'] ); ?>" />
    </p>
    <?php
}
 
add_filter( 'woocommerce_min_password_strength', 'wpglorify_woocommerce_password_filter', 10 );
function wpglorify_woocommerce_password_filter() {
    return 2; 
} //2 represent medium strength password


function woocommerce_ajax_add_to_cart_js() {
    if (function_exists('is_product') && is_product()) {
        wp_enqueue_script('woocommerce-ajax-add-to-cart', plugin_dir_url(__FILE__) . 'assets/js/ajax-add-to-cart.js', array('jquery'), '', true);
    }
}
add_action('wp_enqueue_scripts', 'woocommerce_ajax_add_to_cart_js', 99);
  