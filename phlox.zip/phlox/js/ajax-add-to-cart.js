(function ($) {
    $( document ).on( 'click', '.single_add_to_cart_button', function(e) {
        // e.preventDefault();
        // var product_id = $(this).attr("product_id");
        // var product_qty = 1;
        // var data = {
        //     action: 'woocommerce_ajax_add_to_cart',
        //     product_id: product_id,
        //     product_sku: '',
        //     quantity: product_qty,
        //     variation_id: 0,
        // };
    });
})(jQuery);