<?php
    /*
    * Template name:Page Payment
    */
    get_header();
?>
    <style>
        table {
            width: auto;
            margin: auto;
        }

        form {
            text-align: center;
        }

        .text-right {
            text-align: right;
        }

        .text-left {
            text-align: left;
        }

        .text-center {
            text-align: center;
        }
    </style>
    <?php
        global $wpdb;
        if(isset($_GET["id"])) {
            $user_id = $_GET["id"];
            $sql            = "SELECT * FROM wpky_user_membership INNER JOIN wpky_membership_recurring_payments ON wpky_membership_recurring_payments.id=wpky_user_membership.membership_option_id WHERE user_id=".$user_id;
            $memberships    = $wpdb->get_results($sql);

            if(count($memberships)>0) {
                $membership     = $memberships[0]; 
            } else {
                wp_redirect( '/adquiere-un-plan-de-renta/' );
                exit;  
            }
        } else {
            wp_redirect( '/adquiere-un-plan-de-renta/' );
            exit;
        }

    ?>
    <form method="post" action="" style="text-align: center;">
        <h1 style="text-align: center;">Adquiere un plan de renta</h1>

        <h3>You are going to pay $<?php echo $membership->price; ?></h3>
        <h3>Inscription: share only one time</h3>
        <h3>Membership: recurrent payment</h3>
        <input type="hidden" name="user_id" value="<?php echo $user_id; ?>">
        <!-- <table>
            <tr>
                <td class="text-right">Name on the card : </td>
                <td><input type="text" name="cardname" placeholder="Juan Perez Perez"></td>
            </tr>
            <tr>
                <td class="text-right">Card number : </td>
                <td><input type="text" name="cardnum" placeholder="5555-5555-5555-5555"></td>
            </tr>
            <tr>
                <td class="text-right">Exp : </td>
                <td><input type="text" name="cardexp" placeholder="MM/YY"></td>
            </tr>
            <tr>
                <td class="text-right">CVV : </td>
                <td><input type="text" name="cardcvv" placeholder="123"></td>
            </tr>
        </table>
        <input type="submit" name="add_credit_card" value="PAGAR" style="margin-top: 50px;"><br> -->
        <button type="button" onclick="paywithPaypal()">Pay with Paypal</button>
    </form>
    

    <?php 
        $shortcode = "[wp_paypal button='buynow' name='My product' amount='$membership->price' currency_code='MXN' return='https://www.gamefreaks.com.mx/thank-you-purchase?amount=$membership->price']";
        echo do_shortcode($shortcode); 
    ?>
    <script>
        var forms = document.getElementsByTagName("form");
        var paypal_form = forms[2];
        paypal_form.style.display="none";

        function paywithPaypal() {
            document.getElementsByName("currency_code")[0].value="MXN";
            paypal_form.submit();
        }
    </script>
<?php
    get_footer();