<?php
/*
* Template Name:register
*/
get_header();





if(isset($_REQUEST['Register'])){

 
 
 
 
 echo '<pre>';
 print_R($_REQUEST);
 echo '</pre>';
 
 
 
      
     
      $user_id = wp_insert_user($user_detail);

    if ( $user_id && !is_wp_error( $user_id ) ) {

        $code = sha1( $user_id . time() );    
        global $wpdb;    
      
      
      
        $wpdb->update( 
            'wp_users', //table name     
                array( 'user_activation_key' => $code,  // string    ),       
                array( 'ID' =>    $user_id ),     
                array( '%s', )
            
            ));

        $activation_link = add_query_arg( array( 'key' => $code, 'user' => $user_id ), get_permalink( /* your activation page id here*/ ));  

        wp_mail( $user_email, 'SUBJECT', 'Activation link : ' . $activation_link );
    } 
    
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 


}













?>
<link href="//netdna.bootstrapcdn.com/twitter-bootstrap/2.3.2/css/bootstrap-combined.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//netdna.bootstrapcdn.com/twitter-bootstrap/2.3.2/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<form class="form-horizontal" action='' method="POST">
  <fieldset>
    <div id="legend">
      <legend class="">Register</legend>
    </div>
    <div class="control-group">
      <!-- Username -->
      <label class="control-label"  for="username">Nombre(s):</label>
      <div class="controls">
        <input type="text" id="username" name="nombre" placeholder="" class="input-xlarge">
      
      </div>
    </div>
 
 <div class="control-group">
      <!-- Username -->
      <label class="control-label"  for="username">Apellidos: </label>
      <div class="controls">
        <input type="text" id="username" name="apellidos" placeholder="" class="input-xlarge">
  
      </div>
    </div>
	<div class="control-group">
      <!-- Username -->
      <label class="control-label"  for="username">Fecha de nacimiento:</label>
      <div class="controls">
        <input type="text" id="username" name="fechade" placeholder="" class="input-xlarge">
    
      </div>
    </div>
	<div class="control-group">
      <!-- Username -->
      <label class="control-label"  for="username">Dirección:
Calle:</label>
      <div class="controls">
        <input type="text" id="username" name="dirección" placeholder="" class="input-xlarge">
   
      </div>
    </div>
	<div class="control-group">
      <!-- Username -->
      <label class="control-label"  for="username">Número interior: </label>
      <div class="controls">
        <input type="text" id="username" name="numerointerior" placeholder="" class="input-xlarge">
       
      </div>
    </div>
	<div class="control-group">
      <!-- Username -->
      <label class="control-label"  for="username">Número exterior:</label>
      <div class="controls">
        <input type="text" id="username" name="numerexterior" placeholder="" class="input-xlarge">
        
      </div>
    </div>
	<div class="control-group">
      <!-- Username -->
      <label class="control-label"  for="username">Colonia: </label>
      <div class="controls">
        <input type="text" id="username" name="colonia" placeholder="" class="input-xlarge">
      
      </div>
    </div>
	<div class="control-group">
      <!-- Username -->
      <label class="control-label"  for="username">Municipio: </label>
      <div class="controls">
        <input type="text" id="username" name="municipio" placeholder="" class="input-xlarge">
      
      </div>
    </div>
	<div class="control-group">
      <!-- Username -->
      <label class="control-label"  for="username">Código Postal:</label>
      <div class="controls">
        <input type="text" id="username" name="postal" placeholder="" class="input-xlarge">
   
      </div>
    </div>
	<div class="control-group">
      <!-- Username -->
      <label class="control-label"  for="username">Estado: </label>
      <div class="controls">
        <input type="text" id="username" name="estado" placeholder="" class="input-xlarge">
       
      </div>
    </div><div class="control-group">
      <!-- Username -->
      <label class="control-label"  for="username">Referencias del domicilio: </label>
      <div class="controls">
        <input type="text" id="username" name="referencias" placeholder="" class="input-xlarge">
        
      </div>
    </div><div class="control-group">
      <!-- Username -->
      <label class="control-label"  for="username">(color, fachada, algún local cercano, descripción
de casa cercanas)
Entre que calles: </label>
      <div class="controls">
        <input type="text" id="username" name="quecalles" placeholder="" class="input-xlarge">
 
      </div>
    </div><div class="control-group">
      <!-- Username -->
      <label class="control-label"  for="username">Información para tu cuenta
Correo electrónico:</label>
      <div class="controls">
        <input type="text" id="username" name="informaciónpara" placeholder="" class="input-xlarge">
       
      </div>
    </div><div class="control-group">
      <!-- Username -->
      <label class="control-label"  for="username">Contraseña:</label>
      <div class="controls">
        <input type="text" id="username" name="contraseña" placeholder="" class="input-xlarge">
 
      </div>
    </div>
    
    <div class="control-group">
      <!-- Username -->
      <label class="control-label"  for="username">Repetir contraseña: </label>
      <div class="controls">
        <input type="text" id="username" name="repetircontraseña" placeholder="" class="input-xlarge">
      
      </div>
    </div>
	
    
      <div class="control-group">
      <!-- Username -->
      <label class="control-label"  for="username">Teléfono: </label>
      <div class="controls">
        <input type="text" id="username" name="Telefono" placeholder="" class="input-xlarge">
      
      </div>
    </div>
    
    
    
  
  
 
    <div class="control-group">
      <!-- Button -->
      <div class="controls">
        <input type="submit" class="btn btn-success" value="Register" name="Register"> 
      </div>
    </div>
  </fieldset>
</form>

<?php
get_footer();