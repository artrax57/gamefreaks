<?php
    /*
    * Template name:Page Payment Options
    */
    get_header();
    
    global $wpdb;
    $prefix = $wpdb->prefix;
    if(isset($_POST['membership_id'])) {
        $membership_id  = $_POST['membership_id'];
        $sql            = "SELECT * FROM ".$prefix."membership_types WHERE membership_status=1 AND id=".$membership_id;
        $memberships    = $wpdb->get_results($sql);
        $membership     = $memberships[0];  
        
        //GET all payment options for selected membership
        $sql            = "SELECT * FROM ".$prefix."membership_recurring_payments WHERE status=1 AND membership_id=".$membership_id." Order By monthly_frequency DESC";
        $pay_options    = $wpdb->get_results($sql);
    } else {
        wp_redirect( 'cccc' );
        exit;
    }
?>
    <form method="post" action="/gateway/" class="t-center" id="id_form">
        <h2>Paso 3 - Selecciona el monto que deseas pagar</h2>
        <h2><?php echo $membership->membership_name ?></h2>
        <h2><?php echo $membership->titles_number?> videojuegos</h2>
        <div class="cc-selector-2 d-flex j-center">
            <input type="hidden" name="membership_id"  value="<?php echo $membership->id?>" />
            <?php for($i=0; $i<count($pay_options); $i++) { ?>
                <div class="merbership_card" onclick="selectPaymentOption('id_payment_options_<?php echo $pay_options[$i]->id; ?>')">
                    <?php 
                        if($i==0) {
                            echo "<div class='div_major'>Mejor oferta</div>";
                        }
                    ?>
                    <input id="id_payment_options_<?php echo $pay_options[$i]->id; ?>" type="radio" name="payment_option" class="d-none" value="<?php echo $pay_options[$i]->id; ?>" />
                    <h3>Pago cada <?php echo $pay_options[$i]->monthly_frequency; ?> meses</h3>
                    <h3>$<?php echo number_format($pay_options[$i]->price); ?></h3>

                    <!-- <?php
                    if($membership->titles_number == 2) {
                        if($i==0) { ?>
                            <h4>(ahorras $960 al año)</h4>
                            <h4>57,000 Freakies</h4>
                        <?php } else if($i==1) { ?>
                            <h4>(ahorras $720 al año)</h4>
                            <h4>30,000 Freakies</h4>
                        <?php } else { ?>
                            <h4></h4>
                            <h4>16,800 Freakies</h4>
                        <?php }
                    } else {
                        if($i==0) { ?>
                            <h4>(ahorras $720 al año)</h4>
                            <h4>30,000 Freakies</h4>
                        <?php } else if($i==1) { ?>
                            <h4>(ahorras $360 al año)</h4>
                            <h4>16,800 Freakies</h4>
                        <?php } else { ?>
                            <h4></h4>
                            <h4>9,300 Freakies</h4>
                        <?php }
                    } ?> -->
                </div>
            <?php } ?>
        </div>
        
        <a href="/adquiere-un-plan-de-renta/">
            <input type="button" value="Back" class="mt-5"/>
        </a>
    </form>
    
    <script>
        function selectPaymentOption(id) {
            var cards = document.getElementsByClassName("merbership_card");
            for(var i=0; i<cards.length; i++) {
                cards[i].classList.remove("selected");
            }
            document.getElementById(id).parentElement.classList.add("selected");
            document.getElementById(id).checked = true;
            
            document.getElementById("id_form").submit();
        }
    </script>
<?php
get_footer();