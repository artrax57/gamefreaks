<?php
/*
* Template name:Page second package selection
*/
get_header();
?>
<style>
    
    .cc-selector input{
    margin:0;padding:0;
    -webkit-appearance:none;
       -moz-appearance:none;
            appearance:none;
}

.cc-selector-2 input{
    position:absolute;
    z-index:999;
}

.visa{background-image:url(https://www.gamefreaks.com.mx/wp-content/uploads/2020/10/Screenshot_6.png);}
.mastercard{background-image:url(https://www.gamefreaks.com.mx/wp-content/uploads/2020/10/Screenshot_7.png);}

.cc-selector-2 input:active +.drinkcard-cc, .cc-selector input:active +.drinkcard-cc{opacity: .9;}
.cc-selector-2 input:checked +.drinkcard-cc, .cc-selector input:checked +.drinkcard-cc{
    -webkit-filter: none;
       -moz-filter: none;
            filter: none;
}
.drinkcard-cc{
    cursor:pointer;
    background-size:contain;
    background-repeat:no-repeat;
    display:inline-block;
    width: 400px;
    height: 500px;
    -webkit-transition: all 100ms ease-in;
       -moz-transition: all 100ms ease-in;
            transition: all 100ms ease-in;
    -webkit-filter: brightness(1.8) grayscale(1) opacity(.7);
       -moz-filter: brightness(1.8) grayscale(1) opacity(.7);
            filter: brightness(1.8) grayscale(1) opacity(.7);
}
.drinkcard-cc:hover{
    -webkit-filter: brightness(1.2) grayscale(.5) opacity(.9);
       -moz-filter: brightness(1.2) grayscale(.5) opacity(.9);
            filter: brightness(1.2) grayscale(.5) opacity(.9);
}

/* Extras */
a:visited{color:#888}
a{color:#444;text-decoration:none;}
p{margin-bottom:.3em;}
* { font-family:monospace; }
.cc-selector-2 input{ margin: 5px 0 0 12px; }
.cc-selector-2 label{ margin-left: 7px; }
span.cc{ color:#6d84b4 }


</style>
<form method="post" action="">
 
    <h1 style="
    text-align: center;
">Adquiere un plan de renta

</h1>

    <h2 style="
    text-align: center;
">

Paso 2 - Selecciona la forma de pago de la
inscripción
</h2>
    <div class="cc-selector-2" style="
    text-align: center;
">
        <input id="visa2" type="radio" name="creditcard" value="visa" />
        <label class="drinkcard-cc visa" for="visa2"></label>
        <input  checked="checked" id="mastercard2" type="radio" name="creditcard" value="mastercard" />
        <label class="drinkcard-cc mastercard"for="mastercard2"></label>
    </div>
    <input type="submit" value="submit" name="submit" style="margin-left:250px"/>
</form>

<?php
get_footer();