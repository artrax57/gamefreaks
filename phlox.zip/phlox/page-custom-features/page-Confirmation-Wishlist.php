    <?php
        /*
        * Template name:Page Confirmation WishList
        */
        get_header();
    ?>
    <style>
        .alert_h4 {
            margin: auto; 
            text-align: center; 
            margin-top: 50px; 
            margin-bottom: 50px;
        }

        .wishlist {
            max-width: 1000px; 
            margin: auto;
        }

        .wishlist td {
            text-align: center;
        }

        .wishlist img {
            width: 100%;
        }

        .wishlist a {
            width: 100%; 
            display: block; 
            margin-top: 10px; 
            color: white; 
            text-align: center;
            padding: 5px;
        }
        .a_espera {
            background: #1bb0ce;
            padding: 5px; 
            border-radius: 25px;
        }

        .a_confirm {
            width: 100%; 
            display: block; 
            margin-top: 10px; 
            color: white; 
            text-align: center;
            padding: 5px;
            background: #1bb0ce;
            border-radius: 25px; 
            width: 200px; 
            margin: auto;
            color: white !important;
        }

        .a_proceso {
            background: #f1c232;  
            border-radius: 25px;
        }

        .a_Entregado {
            background: #60ff60;  
            border-radius: 25px;
        }

        .a_cambiar {
            background: #00b; 
            border-radius: 25px;
        }

        .a_process_cambia {
            background: orange;  
            border-radius: 25px;
        }

        .a_borrar {
            background: #f00; 
            border-radius: 25px;
        }
    </style>
    <?php

        global $wpdb;
        $prefix = $wpdb->prefix;

        //get current logged in user id
        $user_id = get_current_user_id();
        //This is the number of the games that were approved by the admin
        $admin_approved = 0;
        //This is the number of the games that were approved by the user
        $user_approved  = 0;
        //Thie is the number of the games that were returned
        $is_returned = 0;
        //get all games that were not returned
        $sql = "SELECT ".$prefix."wishlist.*, ".$prefix."posts.ID as ID, ".$prefix."posts.post_title as Title 
                FROM ".$prefix."wishlist 
                    LEFT JOIN ".$prefix."posts ON ".$prefix."wishlist.product_id=".$prefix."posts.ID 
                WHERE is_returned=0 AND ".$prefix."wishlist.user_id =".$user_id." Order By ".$prefix."wishlist.priority";

        $result = $wpdb->get_results($sql);

        if(count($result) == 0) {
            echo "<h4 class='alert_h4'>Por favor, agrega 10 videojuegos a la lista de deseos para poder procesar tu petici&#243;n.</h4>";
        } else {
            for($i=0; $i<count($result); $i++) {
                if($result[$i]->admin_approved == 1) {
                    $admin_approved++;
                }

                if($result[$i]->user_approved == 1) {
                    $user_approved++;
                }

                if($result[$i]->is_returned == 1) {
                    $is_returned++;
                }
            }

            $count = 0;
            if($user_approved==10 && $admin_approved==0) {
                echo "<h4 class='alert_h4' id='id_h4_inprogress'>Tu lista de deseos se est&#225; procesando.</h4>";
            }
            if(count($result)<10) {
                echo "<h4 class='alert_h4' id='id_h4_inprogress'>Tu lista de deseos ahora tiene ".(10-count($result))." título(s) disponible(s) para agregar.</h4>";
                echo "<h4 class='alert_h4' id='id_h4_inprogress'>En este punto, también puedes cambiar el orden de importancia de tu lista de deseos.</h4>";
            }
            for($i=0; $i<count($result); $i++) {
                $product_id     = $result[$i]->ID;
                $img_product_id = get_post_meta( $product_id, '_thumbnail_id', true );
                $img_post       = $wpdb->get_results( "SELECT * FROM ".$prefix."posts WHERE ID = $img_product_id");
                $img_src        = $img_post[0]->guid;
                if($result[$i]->is_returned != 1) {
                    $count = $count + 1;
    ?>
    
    <div class="wishlist">
        <table>
            <tr>
                <td style="width: 10%;">
                <?php if($user_approved < 10) { ?>
                    <?php if($i>0) { ?>
                    <a onclick="submitActionForm('up', <?php echo $product_id; ?>, <?php echo $result[$i]->priority; ?>)">
                        <img src="/wp-content/uploads/2020/10/up_rent.png" style="width:30px;">
                    </a><br>
                    <?php } ?>
                    <?php if($i<(count($result)-1)) {?>
                        <a onclick="submitActionForm('down', <?php echo $product_id; ?>, <?php echo $result[$i]->priority; ?>)">
                            <img src="/wp-content/uploads/2020/10/down-rent.png" style="width:30px;">
                        </a>
                    <?php }
                        } 
                    ?>
                </td>
                <td style="width: 10%;"><?php echo $count; ?></td>
                <td style="width: 15%;"><img src="<?php echo $img_src; ?>"></td>
                <td style="width: 50%;"><?php echo $result[$i]->Title; ?></td>
                <td style="width: 15%;">
                    <?php
                        if($result[$i]->user_approved==1 && $result[$i]->admin_approved==0) {
                            echo "<a class='a_espera on-hold'>En espera</a>";
                        } else if($result[$i]->user_approved==1 && $result[$i]->admin_approved==1) {
                            if($result[$i]->confirmed_delivery!=1) {
                                echo "<a class='a_proceso on-hold'>En proceso</a>";
                            } else {
                                echo "<a class='a_Entregado on-hold'>Entregado</a>";
                            }
                        }
                        if($result[$i]->confirmed_delivery==1) {
                            if($result[$i]->change_request==0) {
                                ?>
                                <a class="a_cambiar on-hold" onclick="submitActionForm('request_change', <?php echo $product_id ?> , 0)">Cambiar</a>
                                <?php
                            } else {
                                echo "<a class='a_process_cambia on-hold'>Proceso de cambio</a>";
                            }
                        }
                        if($user_approved < 10) {
                            echo "<a href='/confirmation-of-wishlist?action=delete&product_id=".$product_id."&user_id=".$user_id."' class='a_borrar'>Borrar</a>";    
                        }
                    ?>
                </td>
            </tr>
        </table>
    </div>
    <?php
            }
        }
        if(count($result) < 10) {
            echo "<h4 class='alert_h4'>Agregar 10 títulos para continuar.</h4>";
        }
    }
    ?>
    
    <form action="" method="POST" id="id_action_form" style="display: none;"> 
        <input type="text" name="action" id="id_action">
        <input type="text" name="product_id" id="id_product">
        <input type="text" name="priority" id="id_priority">
        <input type="text" name="user_id" id="id_user" value="<?php echo $user_id;?>">
    </form>
    
    <form action="" method="POST" id="id_action_user_confirm_form" style="display: none;"> 
        <input type="text" name="action" id="id_action" value="user_confirm">
        <input type="text" name="user_id" id="id_user" value="<?php echo $user_id;?>">
    </form>
    <?php
        //if($user_approved < 10 && count($result)>9) {
            echo "<a href='/confirm-wish-list/' class='a_confirm'>Confirmar lista de deseos</a>";    
        //}
    ?>
    
    <script>
        function submitActionForm(action, product_id, priority) {
            document.getElementById("id_action").value = action;
            document.getElementById("id_product").value = product_id;
            document.getElementById("id_priority").value = priority;
            document.getElementById("id_action_form").submit();
        }
    </script>
    <?php
    get_footer();