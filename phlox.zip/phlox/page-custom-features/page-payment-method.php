<?php
    /*
    * Template name:Page Payment Methods
    */
    get_header();
    global $wpdb;
    $prefix = $wpdb->prefix;
    if(get_current_user_id()) {
        $user_id        = get_current_user_id();
        $payment_option = $_POST['payment_option'];
        $payment_method = "Paypal"; //$_POST['payment_method'];
        $membership = $wpdb->get_results( "SELECT * FROM ".$prefix."membership_recurring_payments WHERE id = $payment_option");
        $membership_duration = $membership[0]->monthly_frequency;
        $registered_date = date("Y-m-d");
        if($membership_duration == 12) {
            $expired_date = date('Y-m-d', strtotime($registered_date. ' + 1 year'));
        } else {
            $expired_date = date('Y-m-d', strtotime($registered_date. ' + ' .$membership_duration. ' month'));
        }

        $exist_memberships = $wpdb->get_results( "SELECT * FROM ".$prefix."user_membership WHERE user_id =".$user_id);
        if(count($exist_memberships) == 0) {
            $wpdb->insert($prefix.'user_membership',array('user_id'=>$user_id, 'membership_option_id'=>$payment_option, 'registered_date'=>$registered_date, 'payment_method'=>$payment_method, 'expired_date'=>$expired_date, 'status'=>1));
        } else {
            $wpdb->query("UPDATE ".$prefix."user_membership SET membership_option_id=".$payment_option.", registered_date='".$registered_date."', payment_method='".$payment_method."', expired_date='".$expired_date."', status=1, is_paid=0 WHERE user_id =".$user_id);
        }

        $sql            = "SELECT * FROM ".$prefix."user_membership INNER JOIN ".$prefix."membership_recurring_payments ON ".$prefix."membership_recurring_payments.id=".$prefix."user_membership.membership_option_id WHERE user_id=".$user_id." ORDER BY ".$prefix."user_membership.id DESC LIMIT 1";
        $memberships    = $wpdb->get_results($sql);

        if(count($memberships)>0) {
            $membership     = $memberships[0]; 
            $paypal_code    = $membership->paypal_code;
            if($paypal_code != "") {
                $paypal_code    = str_replace("startscript", "<script", $paypal_code);
                $paypal_code    = str_replace("endscript", "</script>", $paypal_code);
            }
            
        } else {
            wp_redirect("/adquiere-un-plan-de-renta/");
            exit;  
        }
    } else {
        wp_redirect( '/adquiere-un-plan-de-renta/' );
        exit;
    }
?>
    <form method="post" action="" style="text-align: center; justify-content: center;">
        <h2 style="text-align: center;">Paso 4 - Forma de pago</h2>
        <div class="cc-selector-2" style="text-align: left; width: 340px; margin: auto;">
            <input type="radio" name="payment_method" value="paypal" id="payment_method_paypal" checked /><span style="margin-left: 40px;">Paypal - Tarjeta de crédito o débito </span> <br>
        </div>
        <?php 
            if($paypal_code == "") {
                echo "<button type='button' onclick='paywithPaypal()'>PAGAR AHORA</button>";
            }
        ?>
        <a href="/adquiere-un-plan-de-renta/"><input type="button" value="Regresar" name="submit" style="margin-top: 50px"/></a>
    </form>
    <?php 
        if($paypal_code == "") {
            $shortcode = "[wp_paypal button='buynow' name='My product' amount='$membership->price' return='https://www.gamefreaks.com.mx/thank-you-purchase?amount=$membership->price']";
            echo do_shortcode($shortcode); 
        }
    ?>
    
    <div style="text-align: center;">
        <?php echo $paypal_code; ?>
    </div>
    
    <script>
        var forms = document.getElementsByTagName("form");
        var paypal_form = forms[2];
        //paypal_form.style.display="none";

        function paywithPaypal() {
            if(document.getElementById("payment_method_paypal").checked) {
                paypal_form.submit();
            }
        }
        
        function selectPaymentOption(id) {
            var cards = document.getElementsByClassName("merbership_card");
            for(var i=0; i<cards.length; i++) {
                cards[i].classList.remove("selected");
            }
            document.getElementById(id).parentElement.classList.add("selected");
            document.getElementById(id).checked = true;
        }
    </script>
<?php
    get_footer();