<?php
    /*
    * Template name:Page seven
    */
    if ( !is_user_logged_in()) {
        wp_redirect( '/my-account' ); 
        exit;    
    }
    get_header();
    global $wpdb;
    $prefix = $wpdb->prefix;

    $sql            = "SELECT * FROM ".$prefix."membership_types WHERE membership_status=1";
    $memberships    = $wpdb->get_results($sql);
?>
<form method="post" action="/adquiere-un-plan-de-renta-2/" class="t-center">
    <!-- <h1>Paso 1 - Selecciona el plan de renta</h1>
    <div class="cc-selector-2 d-flex j-center">
        <?php
            for($i=0; $i<count($memberships); $i++) {
        ?>
        <div class="merbership_card" onclick="selectMembership('id_membership_<?php echo $memberships[$i]->id?>')">
            <input id="id_membership_<?php echo $memberships[$i]->id?>" type="radio" name="membership_id" class="d-none" value="<?php echo $memberships[$i]->id?>" />
            <h3><?php echo $memberships[$i]->membership_name; ?></h3>
            <h1>$<?php echo number_format($memberships[$i]->membership_price); ?></h1>
            <h3><?php echo $memberships[$i]->titles_number; ?> videojuego</h3>
        </div>
        <?php
            }
        ?>
    </div>
    <input type="submit" value="Siguiente" name="submit" class="mt-5" /> -->
    <div class="entry-main">
        <style>
            .merbership-card {
                color: white; 
                width: 200px; 
                height: 200px; 
                background-color: red; 
                text-align: center; 
                font-weight: bolder; 
                font-size: 25px; 
                padding-top: 52px;
            }

            .selected {
                background-color: blue; 
            }

        </style>
        <div class="entry-content">
            <h2>Selecciona el plan ideal para ti</h2>
            <p>Puedes cambiar de plan o cancelar cuando quieras.<br>Selecciona el plan que más te guste.</p>
            <figure class="wp-block-table">
                <table style="width: 900px; margin: auto;">
                    <tbody>
                        <tr>
                            <td></td>
                            <?php
                                for($i=0; $i<count($memberships); $i++) {
                            ?>
                            <td>
                                <div class="merbership-card" style="" onclick="selectMembership('id_membership_<?php echo $memberships[$i]->id?>')">
                                    <input id="id_membership_<?php echo $memberships[$i]->id?>" type="radio" name="membership_id" class="d-none" value="<?php echo $memberships[$i]->id?>" />
                                    Cuenta <?php echo $memberships[$i]->membership_name; ?>
                                </div>
                            </td>
                            <?php
                                }
                            ?>
                        </tr>
                        <tr>
                            <td>Precio mensual</td>
                            <!-- <?php
                                for($i=0; $i<count($memberships); $i++) {
                            ?>
                            <td>$<?php echo number_format($memberships[$i]->membership_price); ?></td>
                            <?php
                                }
                            ?> -->
                            <td>$300</td>
                            <td>$500</td>
                        </tr>
                        <tr>
                            <td>Precio anual</td>
                            <!-- <?php
                                for($i=0; $i<count($memberships); $i++) {
                            ?>
                            <td>$<?php echo number_format($memberships[$i]->membership_price); ?></td>
                            <?php
                                }
                            ?> -->
                            <td>$3,600</td>
                            <td>$6,000</td>
                        </tr>
                        <tr>
                            <td>Renta de videojuegos de forma simultanea</td>
                            <?php
                                for($i=0; $i<count($memberships); $i++) {
                            ?>
                            <td><?php echo number_format($memberships[$i]->titles_number); ?></td>
                            <?php
                                }
                            ?>
                        </tr>
                        <tr></tr>
                        <tr>
                            <td>Renta de forma ilimitada</td>
                            <?php
                                for($i=0; $i<count($memberships); $i++) {
                            ?>
                            <td>Sí</td>
                            <?php
                                }
                            ?>
                        </tr>
                        <tr>
                            <td>Cancela cuando quieras</td>
                            <?php
                                for($i=0; $i<count($memberships); $i++) {
                            ?>
                            <td>Sí</td>
                            <?php
                                }
                            ?>
                        </tr>
                    </tbody>
                </table>
            </figure>

            <p>
                <small>La disponibilidad en la entrega de los títulos agregados a tu lista de deseos dependerá del orden de importancia en que los hayas acomodado.&nbsp;
                    <a href="https://www.netflix.com/termsofuse" target="_blank" rel="noreferrer noopener">Términos de uso</a>&nbsp;para obtener más información.
                </small>
            </p>
            <div class="wp-block-buttons aligncenter">
                <div class="wp-block-button">
                    <input type="submit" value="CONTINUAR" name="submit" class="wp-block-button__link has-background has-vivid-red-background-color" />
                </div>
            </div>
            <p>¿Preguntas? Envía un correo a <a href="mailto:contacto@gamefreaks.com.mx">contacto@gamefreaks.com.mx</a></p>
            <div class="clear"></div>
        </div> <!-- end article section -->

        <footer class="entry-meta"></footer> <!-- end article footer -->
    </div>
</form>

<script>
    function selectMembership(id) {
        var cards = document.getElementsByClassName("merbership-card");
        for(var i=0; i<cards.length; i++) {
            cards[i].classList.remove("selected");
        }
        document.getElementById(id).parentElement.classList.add("selected");
        document.getElementById(id).checked = true;
    }
</script>
<?php
    get_footer();