<?php
    /*
    * Template name:Page Wish List Confirm
    */
    get_header();
?>
    <div style="max-width: 1000px; margin: auto;">
        <div id="id_div_confirm_udpate_user_detail" style="text-align: center;">
            <h4 class="text-center">¿Estás seguro de confirmar la lista de deseos?</h4>
            <h4 class="text-center">Una vez que confirmes tu lista de deseos ya no podrás cambiar el orden en el que deseas jugar los títulos seleccionados ni cambiar los 10 títulos que seleccionaste de la lista de deseos por otros.</h4>
            <h4 class="text-center">Podrás modificar el orden o cambiar títulos hasta que regreses un videojuego y así sucesivamente.</h4>
            <div style="display: flex; width: 50%; margin: auto;">
                <button class="btn-edit-profile ma-au" type="button" onclick="submitActionForm('user_confirm', 0, 0)" style="background: #1bb0ce; width: 100px; display: block; margin-top: 10px; color: white; text-align: center; padding: 5px; border-radius: 25px; border: none;">Si</button>
                <a href="/confirmation-of-wishlist/" class="btn-edit-profile ma-au" style="background: #1bb0ce; width: 100px; display: block; margin-top: 10px; color: white; text-align: center; height: 23px; border-radius: 25px; border: none; margin-left: 52%;">No</a> 
            </div>
        </div>
    </div>
    
    <form action="" method="POST" id="id_action_form" style="display: none;"> 
        <input type="text" name="action" id="id_action">
        <input type="text" name="product_id" id="id_product">
        <input type="text" name="priority" id="id_priority">
        <input type="text" name="user_id" id="id_user" value="<?php echo get_current_user_id();?>">
    </form>
    
    <script>
        function submitActionForm(action, product_id, priority) {
            document.getElementById("id_action").value      = action;
            document.getElementById("id_product").value     = product_id;
            document.getElementById("id_priority").value    = priority;
            document.getElementById("id_action_form").submit();
        }
    </script>
<?php
    get_footer();