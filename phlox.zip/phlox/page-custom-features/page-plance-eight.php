<?php
    /*
    * Template name:Page Eight
    */
    get_header();
?>
    <style>
        .cc-selector input{
            margin:0;padding:0;
            -webkit-appearance:none;
            -moz-appearance:none;
            appearance:none;
        }
    
        .cc-selector-2 input{
            position:absolute;
            z-index:999;
        }
    
        .visa{
            background-image:url(https://www.gamefreaks.com.mx/wp-content/uploads/2020/10/Screenshot_4.png);
        }
        
        .mastercard{
            background-image:url(https://www.gamefreaks.com.mx/wp-content/uploads/2020/10/Screenshot_5.png);
        }
    
        .cc-selector-2 input:active +.drinkcard-cc, .cc-selector input:active +.drinkcard-cc{
            opacity: .9;
        }
        
        .cc-selector-2 input:checked +.drinkcard-cc, .cc-selector input:checked +.drinkcard-cc{
            -webkit-filter: none;
            -moz-filter: none;
            filter: none;
        }
        
        .drinkcard-cc{
            cursor:pointer;
            background-size:contain;
            background-repeat:no-repeat;
            display:inline-block;
            width: 400px;
            height: 500px;
            -webkit-transition: all 100ms ease-in;
            -moz-transition: all 100ms ease-in;
            transition: all 100ms ease-in;
            -webkit-filter: brightness(1.8) grayscale(1) opacity(.7);
            -moz-filter: brightness(1.8) grayscale(1) opacity(.7);
            filter: brightness(1.8) grayscale(1) opacity(.7);
        }
        
        .drinkcard-cc:hover{
            -webkit-filter: brightness(1.2) grayscale(.5) opacity(.9);
            -moz-filter: brightness(1.2) grayscale(.5) opacity(.9);
            filter: brightness(1.2) grayscale(.5) opacity(.9);
        }
    
        /* Extras */
        a:visited{color:#888}
        a{color:#444;text-decoration:none;}
        p{margin-bottom:.3em;}
        * { font-family:monospace; }
        .cc-selector-2 input{ margin: 5px 0 0 12px; }
        .cc-selector-2 label{ margin-left: 7px; }
        span.cc{ color:#6d84b4 }
        
        .merbership_card {
            height: 241px; 
            width: 400px; 
            border: 2px solid #000; 
            margin-right: 20px;
        }
        
        .selected {
            background-color: rgba(0, 0, 0, 0.4);
        }
    </style>
    <?php
        global $wpdb;
        if(isset($_POST['membership_id'])) {
            $membership_id  = $_POST['membership_id'];
            $sql            = "SELECT * FROM wpky_membership_types WHERE membership_status=1 AND id=".$membership_id;
            $memberships    = $wpdb->get_results($sql);
            $membership     = $memberships[0];  
        } else {
            wp_redirect( '/adquiere-un-plan-de-renta/' );
            exit;
        }
    ?>
    <form method="post" action="/adquiere-un-plan-de-renta-2/" style="text-align: center;" id="id_form_payment_plan">
        <h1 style="text-align: center;">Adquiere un plan de renta</h1>
        <h2 style="text-align: center;">Paso 2 - Selecciona la forma de pago de la inscripción</h2>
         
        <div class="cc-selector-2" style="text-align: center; display: flex; justify-content: center;">
            <input type="hidden" name="membership_id"  value="<?php echo $membership->id?>" />
            <div class="merbership_card selected" onclick="selectPaymentMethod('id_payment_money_freakie')">
                <input id="id_payment_money_freakie" type="radio" name="payment_method" style="display: none;" checked value="money_freakie" />
                <h1>$<?php echo number_format($membership->membership_price); ?></h1>
                <h2>Solo un pago</h2>
                <h2>10,500 Freakies</h2>
            </div>
            <?php if($membership->accept_physical_product) { ?>
            <table style="width: 400px; border: none;">
                <tr><td style="border: none; padding: 0; text-align: center;">
                    <div class="merbership_card" onclick="selectPaymentMethod('id_payment_physical_product')">
                        <h1>$0</h1>
                        <input id="id_payment_physical_product" type="radio" name="payment_method" style="display: none;" value="physical_product" />
                        <h3>Entrega <?php echo $membership->accept_physical_product_num; ?> video juego en buenas condiciones.</h3>
                    </div>
                </td></tr>
                <tr><td style="border: none; padding: 0;">
                        <div class="merbership_card" style="border: none;">
                            <p style="text-align: left">1. Juego físico y no descargable.</p>
                            <p style="text-align: left">2. Fecha de publicación menor a 6 meses.</p>
                            <p style="text-align: left">3. En buen estado de uso y funcionamiento.</p>
                            <p style="text-align: left">4. Que NO sean "Ediciones especiales".</p>
                            <p style="text-align: left">5. No FIFA o juegos que anualmente sale una nueva versión del juego.</p>
                        </div>
                </td></tr>
            </table>
            
            <?php } ?>
        </div>
        
        <input type="submit" value="Siguiente" name="submit" style="margin-top: 50px" />
    </form>
    
    <script>
        function selectPaymentMethod(id) {
            var cards = document.getElementsByClassName("merbership_card");
            for(var i=0; i<cards.length; i++) {
                cards[i].classList.remove("selected");
            }
            document.getElementById(id).parentElement.classList.add("selected");
            document.getElementById(id).checked = true;
        }
    </script>
<?php
get_footer();