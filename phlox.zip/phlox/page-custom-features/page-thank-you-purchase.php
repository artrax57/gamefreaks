<?php
    /*
    * Template name:Page Thank you Purchase
    */
    get_header();
?>

<div style="text-align: center;">
    <h3>Te hemos enviado un email con los detalles de tu compra.</h3>
    <h3>Ahora puedes agregar 10 títulos a tu lista de deseo para empezar a rentar videojuegos.</h3>
</div>
<?php
    global $wpdb;
    $user_id = get_current_user_id();
    $user    = get_userdata( $user_id );
    $sql     = "SELECT * FROM wpky_user_membership INNER JOIN wpky_membership_recurring_payments ON wpky_membership_recurring_payments.id=wpky_user_membership.membership_option_id WHERE user_id=".$user_id;
    $memberships    = $wpdb->get_results($sql);
    $paid_amount    = $_GET['amount'];

    $sql = "UPDATE wpky_user_membership SET is_paid = 1, paid_amount=".$paid_amount." WHERE user_id =".$user_id." ORDER BY id DESC LIMIT 1";
    $wpdb->query($sql);
    if(count($memberships)>0) {
        $membership     = $memberships[0];  
    
        $to      = $user->user_email;
        $body    = "<h3>Hola ".$user->user_login."</h3>";
        $body    .= "<p>Muchas gracias por adquirir una cuenta Super Freaks con nosotros. Ahora ya puedes rentar dos videojuegos al mismo tiempo para que puedas 
                    jugar tanto tiempo como tú lo desees y poder cambiarlos de forma ilimitada con nosotros.</p>";
        $body    .= "<p>A partir de este momento ya puedes seleccionar los títulos que te apasionen en nuestro catálogo de videojuegos.</p>";
        $body    .= "<p>https://gamefreaks.com</p>";
        $body    .= "<p>Una vez que hayas seleccionado los títulos con los que deseas jugar, personal de nuestra empresa se pondrá en contacto contigo para dar 
                    seguimiento a tus rentas y programar la entrega de los juegos que hayas rentado.</p>";
        $body    .= "<p>El total de tu pago de el pago de inscripción y de el primer cargo recurrente es de $".$_GET['amount'].".</p>";
        $body    .= "<p>Se estará realizando un cobro de forma periódica cada ".$membership->monthly_frequency." meses por la cantidad de ".$membership->monthly_frequency.".</p>";
        $body    .= "<p>Muchas gracias por unirte a Gamefreaks.</p>";
        $body    .= "<p>Atentamente:</p>";
        $body    .= "<p>Ivan</p>";
        $body    .= "<p>Director General Gamefreaks.</p>";
    
        $subject = "Confirmación de compra - Gamefreaks";
    
        $res_admin     = wp_mail( $to, $subject, $body, "Content-Type: text/html\r\n" );
        $res_admin     = wp_mail( "todayforfuture@outlook.com", $subject, $body, "Content-Type: text/html\r\n" );
    }

get_footer();