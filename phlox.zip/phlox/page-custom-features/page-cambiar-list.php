<?php
    /*
    * Template name:Page Cambiar List
    */
    get_header();
    
    global $wpdb;
    $user_id = get_current_user_id();
    $product_id = $_GET['product_id'];
    $admin_approved = 0;
    $result = $wpdb->get_results( "SELECT wpky_wishlist.*, wpky_posts.ID as ID, wpky_posts.post_title as Title FROM wpky_wishlist LEFT JOIN wpky_posts ON wpky_wishlist.product_id=wpky_posts.ID WHERE wpky_wishlist.user_id =".$user_id." AND wpky_wishlist.product_id=".$product_id." Order By wpky_wishlist.priority");
    
    if(count($result) == 0) {
        ?>
        <h4 style="margin: auto; text-align: center; margin-top: 50px; margin-bottom: 50px;"></h4>
        <?
    } else {
        if($result[0]->user_approved==1 && $result[0]->admin_approved==0) {
        ?>
        <h4 style="margin: auto; text-align: center; margin-top: 50px; margin-bottom: 50px;" id="id_h4_inprogress">Tu lista de deseos se est谩 procesando.</h4>
        <?php
        }
        for($i=0; $i<count($result); $i++) {
            $product_id=$result[$i]->ID;
            $img_product_id = get_post_meta( $product_id, '_thumbnail_id', true );
            $img_post = $wpdb->get_results( "SELECT * FROM wpky_posts WHERE ID = $img_product_id");
            $img_src = $img_post[0]->guid;
?>
    <div style="max-width: 1000px; margin: auto;">
        <table>
            <tr>
                <td style="width: 15%; text-align: center;"><img src="<?php echo $img_src; ?>" style="width:100%;"></td>
                <td style="width: 50%; text-align: center;"><?php echo $result[$i]->Title; ?></td>
            </tr>
        </table>
        <?php if($result[$i]->change_request == 0) {?>
        <div id="id_div_confirm_udpate_user_detail" style="text-align: center;">
            <h4 class="text-center">¿Estás seguro de cambiar el videojuego?</h4>
            <div style="display: flex; width: 50%; margin: auto;">
                <button class="btn-edit-profile ma-au" type="button" onclick="submitActionForm('request_change_done', <?php echo $product_id; ?>,0 )" style="background: #1bb0ce; width: 100px; display: block; margin-top: 10px; color: white; text-align: center; padding: 5px; border-radius: 25px; border: none;">Si</button>
                <a href="/confirmation-of-wishlist/" class="btn-edit-profile ma-au" type="button" onclick="cancelUpdateUserDetail()" style="background: #1bb0ce; width: 100px; display: block; margin-top: 10px; color: white; text-align: center; height: 23px; border-radius: 25px; border: none; margin-left: 52%;">No</a> 
            </div>
        </div>
        <?php } else { ?>
            <div id="id_div_confirm_udpate_user_detail" style="text-align: center;">
                <h4 class="text-center">
                    Recibimos la confirmación de cambiar el videojuego. <br>Esperemos que lo hayas disfrutado.<br><br>
                    Se programará la visita a tu domicilio el siguiente fin de semana <br> para el cambio de videojuego. <br>
                </h4>
            </div>
        <?php } ?>
    </div>
<?php
        }
    }
    ?>
    
    <form action="" method="POST" id="id_action_form" style="display: none;"> 
        <input type="text" name="action" id="id_action">
        <input type="text" name="product_id" id="id_product">
        <input type="text" name="priority" id="id_priority">
        <input type="text" name="user_id" id="id_user" value="<?php echo $user_id;?>">
    </form>
    
    <form action="" method="POST" id="id_action_user_confirm_form" style="display: none;"> 
        <input type="text" name="action" id="id_action" value="user_confirm">
        <input type="text" name="user_id" id="id_user" value="<?php echo $user_id;?>">
    </form>
    
    <script>
        function submitActionForm(action, product_id, priority) {
            document.getElementById("id_action").value = action;
            document.getElementById("id_product").value = product_id;
            document.getElementById("id_priority").value = priority;
            
            document.getElementById("id_action_form").submit();
        }
    </script>
    <?php
    get_footer();