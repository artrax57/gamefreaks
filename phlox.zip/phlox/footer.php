<?php
/* The template for displaying the footer.
 * Contains the closing of the body div and all contents
 *
 * 
 * @package    Auxin
 * @author     averta (c) 2014-2020
 * @link       http://averta.net
 */

do_action( 'auxin_before_the_footer' ); ?>

</div><!--! end of #inner-body -->

<?php do_action( "auxin_before_body_close", $post ); ?>

<!-- outputs by wp_footer -->
<?php wp_footer(); ?>
  <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    
    <?php if(is_user_logged_in()) { 
        print_r($_SERVER['REQUEST_URI']);
    ?>
    <input type="hidden" value="Mi cuenta" id="id_flag_login">
    <?php } else {?>
    <input type="hidden" value="Login" id="id_flag_login">
      <script>
        document.getElementsByClassName("elementor-element-73bdf93")[0].style.display = "none";
      </script>
    <?php }?>
    
    <?php
        $current_url = $_SERVER['REQUEST_URI'];
        if (strpos($current_url, 'confirm-register')) { 
          if(isset($_GET['user_id'])) {
            $user_id = $_GET['user_id'];
            $to_admin         = "contacto@gamefreaks.com.mx";
            $to_admin_subject = "confirmaci��n de registro en gamefreaks.com";
            $current_user     = get_userdata($user_id);
            $message          = "El usuario ".$current_user->user_login." ha confirmado su cuenta de Gamefreaks. Este correo se ha enviado desde gamefraks.com";
            $res_admin        = wp_mail( $to_admin, $to_admin_subject, $message, "Content-Type: text/html\r\n" );
            $res_admin        = wp_mail( "todayforfuture@outlook.com", $to_admin_subject, $message, "Content-Type: text/html\r\n" );
          }
        }
    ?>
 <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  <script>
      var $ = jQuery;
      $( function() {
        $( "#datepicker" ).datepicker();
      } );
      
      var my_account_btn = document.getElementsByClassName("aux-text")[0];
      my_account_btn.innerHTML = document.getElementById("id_flag_login").value;
  </script>
<!-- end wp_footer -->
</body>
</html>
